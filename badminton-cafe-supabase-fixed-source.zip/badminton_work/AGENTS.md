# AGENTS.md

Guidance for AI agents and developers working on **Badminton Cafe**, a private doubles badminton league app.

**Start with [PLAN.md](./PLAN.md).** Milestone 1 (the full UI on preview data) is done. Continue from the next unchecked milestone. Milestone 2 begins by *inspecting* the user's existing Supabase project and reporting integration issues before any database change.

## Stack

TanStack Start (React 19, TanStack Router file routes), Vite 8, Tailwind CSS 4 (theme in `src/styles.css`), shadcn/ui in `src/components/ui`, lucide icons, sonner toasts. Deployed on Netlify via `@netlify/vite-plugin-tanstack-start`.

## Architecture

```
src/
  lib/league/
    types.ts       Domain types (Player, Match, PlayerStats, PairStats)
    fixtures.ts    PREVIEW DATA — the only module to swap for Supabase
    store.tsx      LeagueProvider + useLeague(): state and actions (addMatch, updateMatch, deleteMatch, addPlayer, …)
    stats.ts       Pure stats engine: individual, leaderboard, partnerships, daily, form/streaks
    selection.ts   Match-entry selection rules and validation
    time.ts        Asia/Kolkata date keys and formatting
    league.test.ts Vitest unit tests for the rules above
  components/league/
    bits.tsx       Avatar, PageHeader, StatTile, RankBadge, WinBar, Pct, FormDots, EmptyState, ShuttleMark
    match-card.tsx Team-vs-team result card
    match-form.tsx Add/edit match form (used by Add Match and the admin edit dialog)
    nav.ts         Navigation items (adminOnly flag)
  routes/
    index.tsx      Sign-in (landing page)
    _app.tsx       Authenticated shell: desktop sidebar, mobile top bar + bottom nav + "More" sheet
    _app/*.tsx     dashboard, add-match, matches, leaderboard, daily (?date=YYYY-MM-DD), partnerships,
                   players/ (index + $playerId), admin/players (Super Admin)
```

## Domain rules (keep in sync with stats.ts)

- Doubles only. A match has 4 distinct players and a winning team (`'A' | 'B'`). No scores.
- Win % = wins / matches × 100. **5 matches** are needed for the ranked all-time leaderboard; unqualified players are listed separately.
- Ranking sorts by win % descending. **Equal percentages share a rank** (1, 1, 3), compared exactly with cross-multiplication.
- Partnerships are keyed by the sorted pair (`pairKey`), so pick order doesn't matter.
- Daily stats use **Asia/Kolkata** date keys and only that day's matches. Player of the Day is the highest individual wins that day, with joint winners on ties.
- Deactivated players stay in all history and stats but can't be picked for new matches. Editing an old match still allows that match's original (now inactive) players.
- Only the Super Admin edits or permanently deletes matches and manages players. In production this **must be enforced by Supabase RLS**, not only by the UI.

## Conventions and decisions

- Screens read everything through `useLeague()`. When Supabase arrives, keep that interface and replace the internals.
- Full mobile numbers for the seeded players are deliberately **not** in the bundle; fixtures carry only the last 4 digits. Real numbers stay in Supabase.
- The preview signs in as Niyas (Super Admin) by default, and the shell has a "Preview as" switcher. Remove both when real auth lands (Milestone 3).
- Never ship Supabase secret or service-role keys to the browser. Only the publishable key goes in `VITE_*` variables. Admin account creation goes through a server function.
- Colours come from CSS variables (`--court`, `--accent` lime, `--win`, `--loss`, `--gold`/`--silver`/`--bronze`). Fonts: Bricolage Grotesque (display) and Manrope (body). Use the `tabular` utility for numbers.
- The hero image lives in `public/img/` and is served through the Netlify Image CDN (`/.netlify/images?url=/img/court-hero.png&w=…&fm=webp`).
- Read the clock (`new Date()`) in effects or event handlers, never during render, to avoid hydration mismatches. The exception is `todayKey()`, which only changes at IST midnight.
