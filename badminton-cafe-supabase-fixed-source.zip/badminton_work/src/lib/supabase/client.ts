/** Minimal Supabase Auth + PostgREST client using the public REST endpoints.
 * The publishable/anon key is intended for browser use; RLS remains the security boundary.
 */
export type SupabaseSession = {
  access_token: string
  refresh_token: string
  expires_at?: number
  expires_in?: number
  token_type: string
  user: { id: string; email?: string }
}

const url = (import.meta as ImportMeta & { env: Record<string, string | undefined> }).env.VITE_SUPABASE_URL?.replace(/\/$/, '')
const key = (import.meta as ImportMeta & { env: Record<string, string | undefined> }).env.VITE_SUPABASE_ANON_KEY

export const supabaseConfigured = Boolean(url && key)
const SESSION_KEY = 'badminton-cafe-supabase-session'

export function getSession(): SupabaseSession | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(SESSION_KEY)
    return raw ? (JSON.parse(raw) as SupabaseSession) : null
  } catch {
    return null
  }
}

function saveSession(session: SupabaseSession | null) {
  if (typeof window === 'undefined') return
  if (session) window.localStorage.setItem(SESSION_KEY, JSON.stringify(session))
  else window.localStorage.removeItem(SESSION_KEY)
}

async function request<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  if (!url || !key) throw new Error('Supabase is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to the Netlify environment variables.')
  const response = await fetch(`${url}${path}`, {
    ...options,
    headers: {
      apikey: key,
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  })
  const body = await response.text()
  const data = body ? JSON.parse(body) : null
  if (!response.ok) throw new Error(data?.msg || data?.message || data?.error_description || data?.hint || data?.error || `Supabase request failed (${response.status})`)
  return data as T
}

export async function signInWithMobile(mobile: string, password: string): Promise<SupabaseSession> {
  const email = `${mobile}@players.badmintoncafe.app`
  const session = await request<SupabaseSession>('/auth/v1/token?grant_type=password', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  })
  saveSession(session)
  return session
}

export async function signOutSupabase() {
  const session = getSession()
  if (session && url && key) {
    try { await request('/auth/v1/logout', { method: 'POST' }, session.access_token) } catch { /* local sign-out must still complete */ }
  }
  saveSession(null)
}

export async function refreshSession(): Promise<SupabaseSession | null> {
  const session = getSession()
  if (!session) return null
  if (session.expires_at && session.expires_at * 1000 > Date.now() + 60_000) return session
  try {
    const next = await request<SupabaseSession>('/auth/v1/token?grant_type=refresh_token', {
      method: 'POST', body: JSON.stringify({ refresh_token: session.refresh_token }),
    })
    saveSession(next)
    return next
  } catch {
    saveSession(null)
    return null
  }
}

export async function db<T>(table: string, query: string, options: RequestInit = {}, token?: string): Promise<T> {
  return request<T>(`/rest/v1/${table}?${query}`, options, token)
}

export async function authUser(token: string) {
  return request<{ id: string; email?: string }>('/auth/v1/user', {}, token)
}
