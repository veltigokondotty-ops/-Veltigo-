import { describe, expect, it } from 'vitest'
import type { Match, Player } from './types'
import { computeDaily, computeLeaderboard, computePartnerships, computePlayerStats, pairKey } from './stats'
import { EMPTY_SLOTS, optionsForSlot, setSlot, validateMatch } from './selection'
import { istDateKey, istToIso } from './time'

const mk = (id: string, isActive = true): Player => ({
  id,
  name: id.toUpperCase(),
  mobile: null,
  mobileLast4: '0000',
  role: 'member',
  isActive,
  joinedAt: '2026-01-01',
})
const players = ['a', 'b', 'c', 'd', 'e'].map((id) => mk(id))
let n = 0
const match = (teamA: [string, string], teamB: [string, string], winner: 'A' | 'B', day = '2026-11-20', time = '07:00'): Match => ({
  id: `m${++n}`,
  teamA,
  teamB,
  winner,
  playedAt: istToIso(day, time),
  createdBy: 'a',
})

describe('player selection', () => {
  it('removes earlier picks from later lists', () => {
    let s = setSlot(EMPTY_SLOTS, 0, 'a')
    expect(optionsForSlot(s, 1, players).map((p) => p.id)).toEqual(['b', 'c', 'd', 'e'])
    s = setSlot(s, 1, 'b')
    s = setSlot(s, 2, 'c')
    expect(optionsForSlot(s, 3, players).map((p) => p.id)).toEqual(['d', 'e'])
  })

  it('clears a later slot when an earlier slot takes its player', () => {
    let s = setSlot(EMPTY_SLOTS, 0, 'a')
    s = setSlot(s, 1, 'b')
    s = setSlot(s, 2, 'c')
    s = setSlot(s, 3, 'd')
    s = setSlot(s, 0, 'c')
    expect(s).toEqual(['c', 'b', null, 'd'])
  })

  it('rejects duplicates, inactive players and a missing winner', () => {
    const active = new Set(['a', 'b', 'c'])
    const errors = validateMatch({ slots: ['a', 'a', 'b', 'd'], winner: null }, active)
    expect(errors).toContain('A player can only be selected once.')
    expect(errors).toContain('Only active players can be selected.')
    expect(errors).toContain('Choose the winning team.')
  })
})

describe('statistics', () => {
  const matches = [
    match(['a', 'b'], ['c', 'd'], 'A'),
    match(['a', 'c'], ['b', 'd'], 'A'),
    match(['b', 'a'], ['c', 'e'], 'B'),
    match(['a', 'd'], ['b', 'c'], 'A'),
    match(['c', 'b'], ['a', 'd'], 'A'),
  ]

  it('counts wins, losses and win %', () => {
    const a = computePlayerStats(players, matches).find((s) => s.player.id === 'a')!
    expect(a).toMatchObject({ matches: 5, wins: 3, losses: 2, winPct: 60 })
  })

  it('requires 5 matches to qualify and keeps others visible', () => {
    const { qualified, unqualified } = computeLeaderboard(players, matches)
    expect(qualified.map((q) => q.player.id).sort()).toEqual(['a', 'b', 'c'])
    expect(unqualified.map((u) => u.player.id)).toContain('e')
  })

  it('gives equal percentages the same rank', () => {
    const { qualified } = computeLeaderboard(players, matches)
    // a: 3/5, c: 3/5 → share rank 1; b: 2/5 → rank 3
    const rank = Object.fromEntries(qualified.map((q) => [q.player.id, q.rank]))
    expect(rank.a).toBe(rank.c)
    expect(rank.b).toBe(3)
  })

  it('treats partnerships the same regardless of order', () => {
    const { played, totalPairs } = computePartnerships(players, matches)
    expect(totalPairs).toBe(10)
    const ab = played.find((p) => p.key === pairKey('b', 'a'))!
    expect(ab).toMatchObject({ matches: 2, wins: 1, losses: 1 })
  })
})

describe('daily performance (Asia/Kolkata)', () => {
  it('groups by IST date, even late at night UTC', () => {
    // 00:30 IST on the 21st is still the 20th in UTC
    expect(istDateKey(istToIso('2026-11-21', '00:30'))).toBe('2026-11-21')
  })

  it('names joint Players of the Day on equal wins', () => {
    const day = [match(['a', 'b'], ['c', 'd'], 'A', '2026-11-22'), match(['c', 'd'], ['a', 'e'], 'A', '2026-11-22')]
    const other = [match(['e', 'b'], ['c', 'd'], 'A', '2026-11-23')]
    const d = computeDaily(players, [...day, ...other], '2026-11-22')
    expect(d.totalMatches).toBe(2)
    // a, b, c and d each won once that day; e lost once. The next day is ignored.
    expect(d.playerOfTheDay.map((s) => s.player.id).sort()).toEqual(['a', 'b', 'c', 'd'])
    expect(d.topWins).toBe(1)
    expect(d.ranking.find((r) => r.player.id === 'e')).toMatchObject({ wins: 0, losses: 1 })
  })
})
