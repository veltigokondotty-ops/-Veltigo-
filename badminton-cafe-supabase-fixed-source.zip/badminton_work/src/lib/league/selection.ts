// Match-entry player selection rules.
//
// Slots are ordered: Team A player 1, Team A player 2, Team B player 1,
// Team B player 2. Each slot's list excludes every player chosen in an
// earlier slot. Changing an earlier slot clears any later slot that now
// conflicts, so the same player can never appear twice.

import type { Player, TeamSide } from './types'

export type Slots = [string | null, string | null, string | null, string | null]

export const EMPTY_SLOTS: Slots = [null, null, null, null]

export const SLOT_LABELS = ['Team A · Player 1', 'Team A · Player 2', 'Team B · Player 1', 'Team B · Player 2'] as const

export function optionsForSlot(slots: Slots, index: number, selectable: Player[]): Player[] {
  const taken = new Set(slots.slice(0, index).filter(Boolean))
  return selectable.filter((p) => !taken.has(p.id))
}

export function setSlot(slots: Slots, index: number, playerId: string | null): Slots {
  const next = [...slots] as Slots
  next[index] = playerId
  const seen = new Set<string>()
  for (let i = 0; i < next.length; i++) {
    const id = next[i]
    if (!id) continue
    if (i > index && seen.has(id)) next[i] = null
    else seen.add(id)
  }
  return next
}

export interface MatchDraft {
  slots: Slots
  winner: TeamSide | null
}

/** Returns a list of human-readable problems; empty means valid. */
export function validateMatch(draft: MatchDraft, selectableIds: Set<string>): string[] {
  const errors: string[] = []
  const filled = draft.slots.filter((s): s is string => Boolean(s))
  if (filled.length < 4) errors.push('Select all four players.')
  if (new Set(filled).size !== filled.length) errors.push('A player can only be selected once.')
  if (filled.some((id) => !selectableIds.has(id))) errors.push('Only active players can be selected.')
  if (!draft.winner) errors.push('Choose the winning team.')
  return errors
}
