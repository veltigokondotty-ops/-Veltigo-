// All league dates are grouped and displayed in India Standard Time.
export const LEAGUE_TIMEZONE = 'Asia/Kolkata'

const dateKeyFormat = new Intl.DateTimeFormat('en-CA', {
  timeZone: LEAGUE_TIMEZONE,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
})

const timeFormat = new Intl.DateTimeFormat('en-IN', {
  timeZone: LEAGUE_TIMEZONE,
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
})

const timeInputFormat = new Intl.DateTimeFormat('en-GB', {
  timeZone: LEAGUE_TIMEZONE,
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
})

/** YYYY-MM-DD for the given instant, in Asia/Kolkata. */
export function istDateKey(value: string | Date): string {
  return dateKeyFormat.format(typeof value === 'string' ? new Date(value) : value)
}

export function todayKey(): string {
  return istDateKey(new Date())
}

export function isDateKey(value: unknown): value is string {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)
}

export function shiftDateKey(key: string, days: number): string {
  const d = new Date(`${key}T12:00:00Z`)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

/** Convert an IST date key + HH:mm to an ISO timestamp. */
export function istToIso(dateKey: string, hhmm: string): string {
  return new Date(`${dateKey}T${hhmm}:00+05:30`).toISOString()
}

/** HH:mm (24h) in IST, for time inputs. */
export function istTimeInput(iso: string): string {
  return timeInputFormat.format(new Date(iso))
}

export function formatTime(iso: string): string {
  return timeFormat.format(new Date(iso)).replace(/\s?(am|pm)/i, (m) => m.toLowerCase())
}

export function formatDayLabel(key: string, style: 'long' | 'short' = 'long'): string {
  const d = new Date(`${key}T12:00:00Z`)
  return new Intl.DateTimeFormat('en-IN', {
    timeZone: 'UTC',
    weekday: style === 'long' ? 'long' : 'short',
    day: 'numeric',
    month: style === 'long' ? 'long' : 'short',
    year: style === 'long' ? 'numeric' : undefined,
  }).format(d)
}

export function relativeDayLabel(key: string): string {
  const today = todayKey()
  if (key === today) return 'Today'
  if (key === shiftDateKey(today, -1)) return 'Yesterday'
  return formatDayLabel(key, 'short')
}
