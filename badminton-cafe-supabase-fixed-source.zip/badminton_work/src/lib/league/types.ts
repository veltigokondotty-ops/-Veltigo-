// Domain types for Badminton Cafe. Field names are camelCase in the app;
// the Supabase layer (milestone 2) maps them to/from the existing tables.

export type PlayerRole = 'super_admin' | 'member'

export interface Player {
  id: string
  name: string
  /** Full 10-digit mobile number. Only known for players added in-app. */
  mobile: string | null
  /** Last four digits, always present, used for display. */
  mobileLast4: string
  role: PlayerRole
  isActive: boolean
  joinedAt: string
}

export type TeamSide = 'A' | 'B'

export interface Match {
  id: string
  /** [player1, player2] of Team A */
  teamA: [string, string]
  /** [player1, player2] of Team B */
  teamB: [string, string]
  winner: TeamSide
  /** ISO timestamp (UTC). Displayed and grouped in Asia/Kolkata. */
  playedAt: string
  createdBy: string
}

export interface PlayerStats {
  player: Player
  matches: number
  wins: number
  losses: number
  /** 0–100 */
  winPct: number
}

export interface PairStats {
  key: string
  players: [Player, Player]
  matches: number
  wins: number
  losses: number
  winPct: number
}

export type Ranked<T> = T & { rank: number }
