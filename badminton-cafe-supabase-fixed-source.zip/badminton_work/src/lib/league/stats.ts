// Pure statistics engine. Every screen derives its numbers from here so the
// rules (wins, losses, win %, shared ranks, qualification) live in one place.

import type { Match, PairStats, Player, PlayerStats, Ranked } from './types'
import { istDateKey } from './time'

export const MIN_MATCHES_TO_QUALIFY = 5

export function pct(wins: number, matches: number): number {
  return matches === 0 ? 0 : (wins / matches) * 100
}

export function formatPct(value: number): string {
  return `${Number.isInteger(value) ? value.toFixed(0) : value.toFixed(1)}%`
}

export function matchPlayers(m: Match): string[] {
  return [...m.teamA, ...m.teamB]
}

export function winningTeam(m: Match): [string, string] {
  return m.winner === 'A' ? m.teamA : m.teamB
}

export function losingTeam(m: Match): [string, string] {
  return m.winner === 'A' ? m.teamB : m.teamA
}

export function didWin(m: Match, playerId: string): boolean | null {
  if (winningTeam(m).includes(playerId)) return true
  if (losingTeam(m).includes(playerId)) return false
  return null
}

/** Individual stats for every player (including those with zero matches). */
export function computePlayerStats(players: Player[], matches: Match[]): PlayerStats[] {
  const tally = new Map<string, { wins: number; losses: number }>()
  for (const p of players) tally.set(p.id, { wins: 0, losses: 0 })
  for (const m of matches) {
    for (const id of winningTeam(m)) {
      const t = tally.get(id)
      if (t) t.wins++
    }
    for (const id of losingTeam(m)) {
      const t = tally.get(id)
      if (t) t.losses++
    }
  }
  return players.map((player) => {
    const { wins, losses } = tally.get(player.id)!
    const total = wins + losses
    return { player, matches: total, wins, losses, winPct: pct(wins, total) }
  })
}

type Rankable = { wins: number; matches: number }

/** Exact percentage comparison (avoids floating point drift). */
function comparePct(a: Rankable, b: Rankable): number {
  if (a.matches === 0 || b.matches === 0) return (b.matches === 0 ? 0 : b.wins / b.matches) - (a.matches === 0 ? 0 : a.wins / a.matches)
  return b.wins * a.matches - a.wins * b.matches
}

/**
 * Sort by winning % descending. Equal percentages share the same rank
 * (standard competition ranking: 1, 2, 2, 4). Within a tie, more wins then
 * more matches are listed first, for display only.
 */
export function rankByWinPct<T extends Rankable>(items: T[], nameOf: (t: T) => string): Ranked<T>[] {
  const sorted = [...items].sort(
    (a, b) => comparePct(a, b) || b.wins - a.wins || b.matches - a.matches || nameOf(a).localeCompare(nameOf(b)),
  )
  const ranked: Ranked<T>[] = []
  sorted.forEach((item, i) => {
    const prev = ranked[i - 1]
    const rank = prev && comparePct(prev, item) === 0 ? prev.rank : i + 1
    ranked.push({ ...item, rank })
  })
  return ranked
}

export function computeLeaderboard(players: Player[], matches: Match[]) {
  const stats = computePlayerStats(players, matches)
  const qualified = rankByWinPct(
    stats.filter((s) => s.matches >= MIN_MATCHES_TO_QUALIFY),
    (s) => s.player.name,
  )
  const unqualified = stats
    .filter((s) => s.matches < MIN_MATCHES_TO_QUALIFY)
    .sort((a, b) => b.matches - a.matches || a.player.name.localeCompare(b.player.name))
  return { qualified, unqualified }
}

export function pairKey(a: string, b: string): string {
  return a < b ? `${a}|${b}` : `${b}|${a}`
}

/** Every unique two-player combination, regardless of selection order. */
export function computePartnerships(players: Player[], matches: Match[]) {
  const tally = new Map<string, { wins: number; losses: number }>()
  for (const m of matches) {
    const w = winningTeam(m)
    const l = losingTeam(m)
    const wk = pairKey(w[0], w[1])
    const lk = pairKey(l[0], l[1])
    tally.set(wk, { wins: (tally.get(wk)?.wins ?? 0) + 1, losses: tally.get(wk)?.losses ?? 0 })
    tally.set(lk, { wins: tally.get(lk)?.wins ?? 0, losses: (tally.get(lk)?.losses ?? 0) + 1 })
  }

  const all: PairStats[] = []
  const sortedPlayers = [...players].sort((a, b) => a.name.localeCompare(b.name))
  for (let i = 0; i < sortedPlayers.length; i++) {
    for (let j = i + 1; j < sortedPlayers.length; j++) {
      const a = sortedPlayers[i]
      const b = sortedPlayers[j]
      const key = pairKey(a.id, b.id)
      const t = tally.get(key) ?? { wins: 0, losses: 0 }
      const total = t.wins + t.losses
      all.push({ key, players: [a, b], matches: total, wins: t.wins, losses: t.losses, winPct: pct(t.wins, total) })
    }
  }

  const played = rankByWinPct(
    all.filter((p) => p.matches > 0),
    (p) => `${p.players[0].name} ${p.players[1].name}`,
  )
  const unplayed = all.filter((p) => p.matches === 0)
  return { played, unplayed, totalPairs: all.length }
}

export function matchesOnDay(matches: Match[], dateKey: string): Match[] {
  return matches.filter((m) => istDateKey(m.playedAt) === dateKey)
}

/** Daily stats are computed only from that day's matches — separate from all-time. */
export function computeDaily(players: Player[], matches: Match[], dateKey: string) {
  const dayMatches = matchesOnDay(matches, dateKey)
  const stats = computePlayerStats(players, dayMatches).filter((s) => s.matches > 0)
  const ranking = rankByWinPct(stats, (s) => s.player.name)
  const topWins = Math.max(0, ...stats.map((s) => s.wins))
  const playerOfTheDay = topWins > 0 ? stats.filter((s) => s.wins === topWins) : []
  return { dateKey, matches: dayMatches, totalMatches: dayMatches.length, ranking, playerOfTheDay, topWins }
}

/** Distinct IST dates that have matches, newest first, with counts. */
export function matchDays(matches: Match[]): { dateKey: string; count: number }[] {
  const counts = new Map<string, number>()
  for (const m of matches) {
    const k = istDateKey(m.playedAt)
    counts.set(k, (counts.get(k) ?? 0) + 1)
  }
  return [...counts.entries()]
    .map(([dateKey, count]) => ({ dateKey, count }))
    .sort((a, b) => b.dateKey.localeCompare(a.dateKey))
}

/** Most recent results for a player, newest first. */
export function recentForm(playerId: string, matches: Match[], limit = 5): ('W' | 'L')[] {
  return [...matches]
    .sort((a, b) => b.playedAt.localeCompare(a.playedAt))
    .map((m) => didWin(m, playerId))
    .filter((r): r is boolean => r !== null)
    .slice(0, limit)
    .map((won) => (won ? 'W' : 'L'))
}

/** Current streak, e.g. { type: 'W', count: 3 }. */
export function currentStreak(playerId: string, matches: Match[]) {
  const form = recentForm(playerId, matches, matches.length)
  if (form.length === 0) return null
  let count = 0
  for (const r of form) {
    if (r === form[0]) count++
    else break
  }
  return { type: form[0], count }
}
