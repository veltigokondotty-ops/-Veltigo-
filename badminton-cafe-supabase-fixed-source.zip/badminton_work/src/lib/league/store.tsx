import * as React from 'react'
import type { Match, Player, TeamSide } from './types'
import { authUser, db, getSession, refreshSession, signInWithMobile, signOutSupabase, supabaseConfigured } from '@/lib/supabase/client'

export interface NewMatchInput {
  teamA: [string, string]
  teamB: [string, string]
  winner: TeamSide
  playedAt: string
}
export interface PlayerInput { name: string; mobile: string; password?: string }
interface LeagueContextValue {
  players: Player[]; activePlayers: Player[]; matches: Match[]; currentUser: Player | null
  isAdmin: boolean; loading: boolean; error: string | null
  playerById: (id: string) => Player | undefined
  signIn: (mobile: string, password: string) => Promise<Player>
  signOut: () => Promise<void>
  addMatch: (input: NewMatchInput) => Promise<Match>
  updateMatch: (id: string, input: NewMatchInput) => Promise<void>
  deleteMatch: (id: string) => Promise<void>
  addPlayer: (input: PlayerInput) => Promise<Player>
  updatePlayer: (id: string, input: PlayerInput) => Promise<void>
  setPlayerActive: (id: string, isActive: boolean) => Promise<void>
  isDuplicateMobile: (mobile: string, exceptId?: string) => boolean
}
const LeagueContext = React.createContext<LeagueContextValue | null>(null)
export function normalizeMobile(input: string) { const digits = input.replace(/\D/g, ''); return digits.length > 10 ? digits.slice(-10) : digits }
export function maskMobile(p: Pick<Player, 'mobileLast4'>) { return `•••••• ${p.mobileLast4}` }

type DbPlayer = { id: string; name: string; mobile: string; is_active: boolean; created_at: string }
type DbProfile = { user_id: string; player_id: string; role: string }
type DbMatch = { id: string; team_a_player_1: string; team_a_player_2: string; team_b_player_1: string; team_b_player_2: string; winner_team: TeamSide; played_at: string; created_by: string; created_at: string }
const toPlayer = (p: DbPlayer, role: string): Player => ({ id: p.id, name: p.name, mobile: p.mobile, mobileLast4: p.mobile.slice(-4), role: role === 'admin' || role === 'super_admin' ? 'super_admin' : 'member', isActive: p.is_active, joinedAt: p.created_at.slice(0, 10) })
const toMatch = (m: DbMatch): Match => ({ id: m.id, teamA: [m.team_a_player_1, m.team_a_player_2], teamB: [m.team_b_player_1, m.team_b_player_2], winner: m.winner_team, playedAt: m.played_at, createdBy: m.created_by })
const enc = (s: string) => encodeURIComponent(s)

export function LeagueProvider({ children }: { children: React.ReactNode }) {
  const [players, setPlayers] = React.useState<Player[]>([])
  const [matches, setMatches] = React.useState<Match[]>([])
  const [currentUser, setCurrentUser] = React.useState<Player | null>(null)
  const [token, setToken] = React.useState<string | null>(null)
  const [authUserId, setAuthUserId] = React.useState<string | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)

  const loadLeague = React.useCallback(async (accessToken: string, userId: string) => {
    const profiles = await db<DbProfile[]>('profiles', 'select=user_id,player_id,role', {}, accessToken)
    const profile = profiles.find((row) => row.user_id === userId)
    if (!profile) throw new Error('Your login is not linked to a player profile. Contact the Super Admin.')
    const [playerRows, matchRows] = await Promise.all([
      db<DbPlayer[]>('players', 'select=id,name,mobile,is_active,created_at&order=name.asc', {}, accessToken),
      db<DbMatch[]>('matches', 'select=id,team_a_player_1,team_a_player_2,team_b_player_1,team_b_player_2,winner_team,played_at,created_by,created_at&order=played_at.desc', {}, accessToken),
    ])
    const rolesByPlayer = new Map(profiles.map((row) => [row.player_id, row.role]))
    const nextPlayers = playerRows.map((p) => toPlayer(p, rolesByPlayer.get(p.id) ?? 'member'))
    setPlayers(nextPlayers)
    setMatches(matchRows.map(toMatch))
    const me = nextPlayers.find((p) => p.id === profile.player_id)
    if (!me || !me.isActive) throw new Error('This player account is inactive. Contact the Super Admin.')
    setCurrentUser(me)
    setToken(accessToken)
    setAuthUserId(userId)
    return me
  }, [])

  const refresh = React.useCallback(async () => {
    setLoading(true); setError(null)
    try {
      if (!supabaseConfigured) throw new Error('Supabase is not configured. Add the two VITE_SUPABASE environment variables in Netlify.')
      const session = await refreshSession()
      if (!session) { setCurrentUser(null); setPlayers([]); setMatches([]); setToken(null); setAuthUserId(null); return }
      const user = await authUser(session.access_token)
      await loadLeague(session.access_token, user.id)
    } catch (e) { setError(e instanceof Error ? e.message : 'Unable to load Badminton Cafe.'); setCurrentUser(null); setPlayers([]); setMatches([]); setToken(null); setAuthUserId(null) }
    finally { setLoading(false) }
  }, [loadLeague])

  React.useEffect(() => { void refresh() }, [refresh])

  const requireToken = () => { if (!token || !currentUser) throw new Error('Please sign in again.') ; return token }
  const reload = async () => { const t = requireToken(); const s = getSession(); if (!s) return; await loadLeague(t, s.user.id) }
  const playerById = (id: string) => players.find((p) => p.id === id)
  const isDuplicateMobile = (mobile: string, exceptId?: string) => players.some((p) => p.id !== exceptId && p.mobile === normalizeMobile(mobile))

  const value: LeagueContextValue = {
    players, activePlayers: players.filter((p) => p.isActive), matches, currentUser,
    isAdmin: currentUser?.role === 'super_admin', loading, error, playerById,
    signIn: async (mobile, password) => {
      const digits = normalizeMobile(mobile)
      if (!/^\d{10}$/.test(digits)) throw new Error('Enter your 10-digit mobile number.')
      const session = await signInWithMobile(digits, password)
      return await loadLeague(session.access_token, session.user.id)
    },
    signOut: async () => { await signOutSupabase(); setToken(null); setAuthUserId(null); setCurrentUser(null); setPlayers([]); setMatches([]) },
    addMatch: async (input) => {
      const t = requireToken()
      const rows = await db<DbMatch[]>('matches', 'select=*', { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ team_a_player_1: input.teamA[0], team_a_player_2: input.teamA[1], team_b_player_1: input.teamB[0], team_b_player_2: input.teamB[1], winner_team: input.winner, played_at: input.playedAt, created_by: authUserId! }) }, t)
      const created = toMatch(rows[0]); await reload(); return created
    },
    updateMatch: async (id, input) => { const t = requireToken(); await db<unknown>('matches', `id=eq.${enc(id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ team_a_player_1: input.teamA[0], team_a_player_2: input.teamA[1], team_b_player_1: input.teamB[0], team_b_player_2: input.teamB[1], winner_team: input.winner, played_at: input.playedAt }) }, t); await reload() },
    deleteMatch: async (id) => { const t = requireToken(); await db<unknown>('matches', `id=eq.${enc(id)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } }, t); await reload() },
    addPlayer: async (input) => {
      const t = requireToken()
      const response = await fetch('/.netlify/functions/admin-create-player', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` }, body: JSON.stringify({ name: input.name, mobile: normalizeMobile(input.mobile), password: input.password }) })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Unable to create player account.')
      await reload(); return players.find((p) => p.id === data.playerId) ?? ({ id: data.playerId, name: input.name, mobile: normalizeMobile(input.mobile), mobileLast4: normalizeMobile(input.mobile).slice(-4), role: 'member', isActive: true, joinedAt: new Date().toISOString().slice(0, 10) })
    },
    updatePlayer: async (id, input) => { const t = requireToken(); const body: Record<string, unknown> = { name: input.name.trim() }; if (input.mobile) body.mobile = normalizeMobile(input.mobile); await db<unknown>('players', `id=eq.${enc(id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(body) }, t); await reload() },
    setPlayerActive: async (id, isActive) => { const t = requireToken(); await db<unknown>('players', `id=eq.${enc(id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ is_active: isActive }) }, t); await reload() },
  }
  return <LeagueContext.Provider value={value}>{children}</LeagueContext.Provider>
}
// Read the current signed-in user's player mapping after auth completes.
export function useLeague() { const ctx = React.useContext(LeagueContext); if (!ctx) throw new Error('useLeague must be used inside <LeagueProvider>'); return ctx }
