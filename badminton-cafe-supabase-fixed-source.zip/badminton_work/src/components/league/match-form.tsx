import * as React from 'react'
import { AlertCircle, Check, RotateCcw, Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { Player, TeamSide } from '@/lib/league/types'
import { EMPTY_SLOTS, SLOT_LABELS, optionsForSlot, setSlot, validateMatch, type Slots } from '@/lib/league/selection'
import { istDateKey, istTimeInput, istToIso, todayKey } from '@/lib/league/time'
import type { NewMatchInput } from '@/lib/league/store'
import { PlayerAvatar } from './bits'

export interface MatchFormInitial {
  slots: Slots
  winner: TeamSide | null
  playedAt?: string
}

function PlayerSlot({
  index,
  slots,
  selectable,
  playerById,
  onChange,
}: {
  index: number
  slots: Slots
  selectable: Player[]
  playerById: (id: string) => Player | undefined
  onChange: (index: number, id: string | null) => void
}) {
  const options = optionsForSlot(slots, index, selectable)
  const value = slots[index]
  const selected = value ? playerById(value) : undefined
  const id = `slot-${index}`
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id} className="text-xs font-semibold text-muted-foreground">
        {SLOT_LABELS[index].split(' · ')[1]}
      </Label>
      <Select value={value ?? ''} onValueChange={(v) => onChange(index, v || null)}>
        <SelectTrigger id={id} className="h-12 w-full rounded-xl bg-card text-base data-[placeholder]:text-muted-foreground" aria-label={SLOT_LABELS[index]}>
          {selected ? (
            <span className="flex items-center gap-2">
              <PlayerAvatar player={selected} size="xs" />
              <span className="font-semibold">{selected.name}</span>
            </span>
          ) : (
            <SelectValue placeholder="Select player" />
          )}
        </SelectTrigger>
        <SelectContent position="popper" className="max-h-72">
          {options.length === 0 && <div className="px-3 py-2 text-sm text-muted-foreground">No players available</div>}
          {options.map((p) => (
            <SelectItem key={p.id} value={p.id} className="py-2">
              <span className="flex items-center gap-2">
                <PlayerAvatar player={p} size="xs" />
                {p.name}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export function MatchForm({
  selectable,
  playerById,
  initial,
  submitLabel = 'Save match',
  onSubmit,
  onCancel,
}: {
  selectable: Player[]
  playerById: (id: string) => Player | undefined
  initial?: MatchFormInitial
  submitLabel?: string
  onSubmit: (input: NewMatchInput) => void | Promise<void>
  onCancel?: () => void
}) {
  const [slots, setSlots] = React.useState<Slots>(initial?.slots ?? EMPTY_SLOTS)
  const [winner, setWinner] = React.useState<TeamSide | null>(initial?.winner ?? null)
  const [date, setDate] = React.useState('')
  const [time, setTime] = React.useState('')
  const [errors, setErrors] = React.useState<string[]>([])

  // Defaults depend on the current clock, so set them after hydration.
  React.useEffect(() => {
    const at = initial?.playedAt ?? new Date().toISOString()
    setDate(istDateKey(at))
    setTime(istTimeInput(at))
  }, [initial?.playedAt])

  const selectableIds = React.useMemo(() => new Set(selectable.map((p) => p.id)), [selectable])

  const change = (index: number, id: string | null) => {
    setSlots((s) => setSlot(s, index, id))
    setErrors([])
  }

  const reset = () => {
    setSlots(EMPTY_SLOTS)
    setWinner(null)
    setErrors([])
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const problems = validateMatch({ slots, winner }, selectableIds)
    if (!date || !time) problems.push('Choose the match date and time.')
    if (problems.length) {
      setErrors(problems)
      return
    }
    void Promise.resolve(onSubmit({
      teamA: [slots[0]!, slots[1]!],
      teamB: [slots[2]!, slots[3]!],
      winner: winner!,
      playedAt: istToIso(date, time),
    })).then(() => { if (!initial) reset() }).catch((err: unknown) => setErrors([err instanceof Error ? err.message : 'Unable to save match.']))
  }

  const teamName = (a: number, b: number) =>
    [slots[a], slots[b]].map((id) => (id ? playerById(id)?.name : null)).filter(Boolean).join(' & ')

  const team = (side: TeamSide, a: number, b: number) => (
    <fieldset className="rounded-2xl border bg-secondary/50 p-4">
      <legend className="sr-only">Team {side}</legend>
      <div className="mb-3 flex items-center gap-2">
        <span
          className={cn(
            'inline-flex size-7 items-center justify-center rounded-lg font-display text-sm font-extrabold',
            side === 'A' ? 'bg-primary text-primary-foreground' : 'bg-court text-accent',
          )}
        >
          {side}
        </span>
        <p className="font-display font-bold">Team {side}</p>
      </div>
      <div className="grid gap-3">
        <PlayerSlot index={a} slots={slots} selectable={selectable} playerById={playerById} onChange={change} />
        <PlayerSlot index={b} slots={slots} selectable={selectable} playerById={playerById} onChange={change} />
      </div>
    </fieldset>
  )

  return (
    <form onSubmit={submit} className="grid gap-5" noValidate>
      <div className="grid items-center gap-3 md:grid-cols-[1fr_auto_1fr]">
        {team('A', 0, 1)}
        <div className="flex justify-center">
          <span className="rounded-full bg-court px-3 py-1 font-display text-xs font-extrabold tracking-[0.2em] text-accent">
            VS
          </span>
        </div>
        {team('B', 2, 3)}
      </div>

      <fieldset>
        <legend className="mb-2 font-display font-bold">Winning team</legend>
        <div className="grid grid-cols-2 gap-3" role="radiogroup">
          {(['A', 'B'] as const).map((side) => {
            const names = side === 'A' ? teamName(0, 1) : teamName(2, 3)
            const active = winner === side
            return (
              <button
                key={side}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => {
                  setWinner(side)
                  setErrors([])
                }}
                className={cn(
                  'relative flex min-h-20 flex-col items-start justify-center rounded-2xl border-2 p-3 text-left transition-all outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 active:scale-[0.98] motion-reduce:transition-none',
                  active ? 'border-primary bg-accent/50 shadow-sm' : 'border-border bg-card hover:border-primary/40',
                )}
              >
                <span className="flex items-center gap-1.5 font-display font-bold">
                  <Trophy className={cn('size-4', active ? 'text-primary' : 'text-muted-foreground')} aria-hidden />
                  Team {side} won
                </span>
                <span className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{names || 'Players not selected'}</span>
                {active && (
                  <span className="absolute top-2.5 right-2.5 inline-flex size-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Check className="size-3" aria-hidden />
                  </span>
                )}
              </button>
            )
          })}
        </div>
      </fieldset>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="match-date" className="text-xs font-semibold text-muted-foreground">Date (IST)</Label>
          <Input id="match-date" type="date" value={date} max={todayKey()} onChange={(e) => setDate(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="match-time" className="text-xs font-semibold text-muted-foreground">Time (IST)</Label>
          <Input id="match-time" type="time" value={time} onChange={(e) => setTime(e.target.value)} className="h-11 rounded-xl" />
        </div>
      </div>

      {errors.length > 0 && (
        <div role="alert" className="flex gap-2 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
          <ul className="grid gap-0.5">
            {errors.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        {onCancel ? (
          <Button type="button" variant="outline" size="lg" onClick={onCancel} className="rounded-xl">
            Cancel
          </Button>
        ) : (
          <Button type="button" variant="ghost" size="lg" onClick={reset} className="rounded-xl">
            <RotateCcw aria-hidden /> Clear
          </Button>
        )}
        <Button type="submit" size="lg" className="h-12 rounded-xl px-8 text-base font-bold">
          {submitLabel}
        </Button>
      </div>
    </form>
  )
}
