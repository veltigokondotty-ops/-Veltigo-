import * as React from 'react'
import { Crown, Medal } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Player } from '@/lib/league/types'
import { formatPct } from '@/lib/league/stats'

const avatarTones = [
  'bg-[oklch(0.4_0.09_162)] text-[oklch(0.96_0.05_120)]',
  'bg-[oklch(0.86_0.17_122)] text-[oklch(0.25_0.06_150)]',
  'bg-[oklch(0.62_0.11_200)] text-white',
  'bg-[oklch(0.78_0.13_80)] text-[oklch(0.28_0.05_60)]',
  'bg-[oklch(0.3_0.05_165)] text-[oklch(0.9_0.15_122)]',
  'bg-[oklch(0.66_0.12_40)] text-white',
  'bg-[oklch(0.9_0.04_160)] text-[oklch(0.3_0.07_162)]',
]

function toneFor(id: string) {
  let h = 0
  for (const c of id) h = (h * 31 + c.charCodeAt(0)) | 0
  return avatarTones[Math.abs(h) % avatarTones.length]
}

export function initials(name: string) {
  const parts = name.trim().split(/\s+/)
  return (parts.length > 1 ? parts[0][0] + parts[1][0] : name.slice(0, 2)).toUpperCase()
}

export function PlayerAvatar({
  player,
  size = 'md',
  className,
}: {
  player: Pick<Player, 'id' | 'name' | 'isActive'>
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  const sizes = {
    xs: 'size-6 text-[10px]',
    sm: 'size-8 text-xs',
    md: 'size-10 text-sm',
    lg: 'size-14 text-lg',
    xl: 'size-20 text-2xl',
  }
  return (
    <span
      aria-hidden
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-full font-display font-bold tracking-tight ring-2 ring-card',
        sizes[size],
        toneFor(player.id),
        !player.isActive && 'grayscale opacity-60',
        className,
      )}
    >
      {initials(player.name)}
    </span>
  )
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string
  title: string
  description?: React.ReactNode
  actions?: React.ReactNode
}) {
  return (
    <header className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {eyebrow && (
          <p className="mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-primary">{eyebrow}</p>
        )}
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-foreground sm:text-4xl">{title}</h1>
        {description && <p className="mt-1.5 max-w-reading text-sm text-muted-foreground sm:text-base">{description}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </header>
  )
}

export function StatTile({
  label,
  value,
  hint,
  icon,
  tone = 'default',
  className,
}: {
  label: string
  value: React.ReactNode
  hint?: React.ReactNode
  icon?: React.ReactNode
  tone?: 'default' | 'court' | 'lime'
  className?: string
}) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl border p-4 shadow-[0_1px_0_oklch(0_0_0/0.03)]',
        tone === 'default' && 'bg-card',
        tone === 'court' && 'court-lines border-transparent text-sidebar-foreground',
        tone === 'lime' && 'border-transparent bg-accent text-accent-foreground',
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p
          className={cn(
            'text-xs font-semibold uppercase tracking-[0.12em]',
            tone === 'default' ? 'text-muted-foreground' : 'opacity-80',
          )}
        >
          {label}
        </p>
        {icon && <span className={cn('opacity-70 [&_svg]:size-4', tone === 'default' && 'text-primary')}>{icon}</span>}
      </div>
      <p className="tabular mt-2 font-display text-3xl font-extrabold tracking-tight">{value}</p>
      {hint && <p className={cn('mt-0.5 text-xs', tone === 'default' ? 'text-muted-foreground' : 'opacity-80')}>{hint}</p>}
    </div>
  )
}

export function RankBadge({ rank, className }: { rank: number; className?: string }) {
  const medal =
    rank === 1 ? 'bg-gold text-[oklch(0.3_0.06_70)]' : rank === 2 ? 'bg-silver text-[oklch(0.3_0.02_240)]' : rank === 3 ? 'bg-bronze text-white' : null
  return (
    <span
      className={cn(
        'tabular inline-flex size-8 shrink-0 items-center justify-center rounded-full font-display text-sm font-bold',
        medal ?? 'bg-muted text-muted-foreground',
        className,
      )}
      aria-label={`Rank ${rank}`}
    >
      {rank === 1 ? <Crown className="size-4" aria-hidden /> : rank <= 3 ? <Medal className="size-4" aria-hidden /> : rank}
    </span>
  )
}

export function WinBar({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full bg-muted', className)} aria-hidden>
      <div
        className="h-full rounded-full bg-gradient-to-r from-primary to-[oklch(0.75_0.18_130)] transition-[width] duration-500 motion-reduce:transition-none"
        style={{ width: `${Math.max(2, Math.min(100, value))}%` }}
      />
    </div>
  )
}

export function Pct({ value, className }: { value: number; className?: string }) {
  return <span className={cn('tabular font-display font-bold', className)}>{formatPct(value)}</span>
}

export function FormDots({ form, className }: { form: ('W' | 'L')[]; className?: string }) {
  if (form.length === 0) return <span className="text-xs text-muted-foreground">No matches yet</span>
  return (
    <span className={cn('inline-flex items-center gap-1', className)} aria-label={`Recent form: ${form.join(' ')}`}>
      {form.map((r, i) => (
        <span
          key={i}
          className={cn(
            'inline-flex size-5 items-center justify-center rounded-md text-[10px] font-bold',
            r === 'W' ? 'bg-win/15 text-win' : 'bg-loss/15 text-loss',
          )}
        >
          {r}
        </span>
      ))}
    </span>
  )
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: React.ReactNode
  title: string
  description?: string
  action?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed bg-card/60 px-6 py-12 text-center">
      <span className="mb-3 inline-flex size-12 items-center justify-center rounded-full bg-secondary text-primary [&_svg]:size-6">
        {icon}
      </span>
      <p className="font-display text-lg font-bold">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function SectionTitle({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-2">
      <h2 className="font-display text-lg font-bold tracking-tight">{children}</h2>
      {action}
    </div>
  )
}

/** Tiny shuttlecock mark used in the logo. */
export function ShuttleMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden fill="none">
      <path d="M9 4l7 14 7-14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12.5 4L16 18l3.5-14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity=".6" />
      <path d="M10.5 11h11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity=".6" />
      <circle cx="16" cy="23" r="5" fill="currentColor" />
    </svg>
  )
}
