import {
  CalendarDays,
  History,
  LayoutDashboard,
  PlusCircle,
  ShieldCheck,
  Trophy,
  Users,
  UsersRound,
  type LucideIcon,
} from 'lucide-react'

export interface NavItem {
  to: '/dashboard' | '/add-match' | '/matches' | '/leaderboard' | '/daily' | '/partnerships' | '/players' | '/admin/players'
  label: string
  short: string
  icon: LucideIcon
  adminOnly?: boolean
}

export const navItems: NavItem[] = [
  { to: '/dashboard', label: 'Dashboard', short: 'Home', icon: LayoutDashboard },
  { to: '/add-match', label: 'Add Match', short: 'Add', icon: PlusCircle },
  { to: '/matches', label: 'Match History', short: 'History', icon: History },
  { to: '/leaderboard', label: 'All-Time Leaderboard', short: 'Ranks', icon: Trophy },
  { to: '/daily', label: 'Daily Performance', short: 'Daily', icon: CalendarDays },
  { to: '/partnerships', label: 'Partnerships', short: 'Pairs', icon: UsersRound },
  { to: '/players', label: 'Player Profiles', short: 'Players', icon: Users },
  { to: '/admin/players', label: 'Player Management', short: 'Manage', icon: ShieldCheck, adminOnly: true },
]

/** Shown in the mobile bottom bar; everything else lives under "More". */
export const bottomNav: NavItem['to'][] = ['/dashboard', '/matches', '/add-match', '/leaderboard']
