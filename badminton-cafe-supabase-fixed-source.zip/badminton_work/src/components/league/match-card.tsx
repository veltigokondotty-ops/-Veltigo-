import * as React from 'react'
import { Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Match, Player } from '@/lib/league/types'
import { formatTime, relativeDayLabel, istDateKey } from '@/lib/league/time'
import { PlayerAvatar } from './bits'

function TeamRow({
  label,
  ids,
  won,
  playerById,
  highlightId,
}: {
  label: string
  ids: [string, string]
  won: boolean
  playerById: (id: string) => Player | undefined
  highlightId?: string
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors',
        won ? 'bg-accent/45' : 'bg-muted/60',
      )}
    >
      <div className="flex -space-x-2">
        {ids.map((id) => {
          const p = playerById(id)
          return p ? <PlayerAvatar key={id} player={p} size="sm" /> : null
        })}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
        <p className={cn('truncate text-sm', won ? 'font-bold text-foreground' : 'font-medium text-foreground/75')}>
          {ids.map((id, i) => {
            const p = playerById(id)
            return (
              <React.Fragment key={id}>
                {i > 0 && <span className="text-muted-foreground"> & </span>}
                <span className={cn(highlightId === id && 'underline decoration-primary decoration-2 underline-offset-4')}>
                  {p?.name ?? 'Unknown'}
                </span>
              </React.Fragment>
            )
          })}
        </p>
      </div>
      {won ? (
        <span className="inline-flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
          <Trophy className="size-3" aria-hidden /> Won
        </span>
      ) : (
        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Lost</span>
      )}
    </div>
  )
}

export function MatchCard({
  match,
  playerById,
  showDate = true,
  highlightId,
  actions,
  className,
}: {
  match: Match
  playerById: (id: string) => Player | undefined
  showDate?: boolean
  highlightId?: string
  actions?: React.ReactNode
  className?: string
}) {
  return (
    <article className={cn('rounded-2xl border bg-card p-3 shadow-[0_1px_0_oklch(0_0_0/0.03)]', className)}>
      <div className="mb-2 flex items-center justify-between gap-2 px-1">
        <p className="tabular text-xs font-medium text-muted-foreground">
          {showDate && <span>{relativeDayLabel(istDateKey(match.playedAt))} · </span>}
          {formatTime(match.playedAt)}
        </p>
        {actions}
      </div>
      <div className="grid gap-1.5">
        <TeamRow label="Team A" ids={match.teamA} won={match.winner === 'A'} playerById={playerById} highlightId={highlightId} />
        <TeamRow label="Team B" ids={match.teamB} won={match.winner === 'B'} playerById={playerById} highlightId={highlightId} />
      </div>
    </article>
  )
}
