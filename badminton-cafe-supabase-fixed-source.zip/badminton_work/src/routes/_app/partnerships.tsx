import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { UsersRound } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useLeague } from '@/lib/league/store'
import { computePartnerships } from '@/lib/league/stats'
import { EmptyState, PageHeader, Pct, PlayerAvatar, RankBadge, WinBar } from '@/components/league/bits'

export const Route = createFileRoute('/_app/partnerships')({
  head: () => ({ meta: [{ title: 'Partnerships · Badminton Cafe' }] }),
  component: Partnerships,
})

function Partnerships() {
  const { players, matches } = useLeague()
  const { played, unplayed, totalPairs } = computePartnerships(players, matches)
  const [focus, setFocus] = React.useState('all')
  const list = focus === 'all' ? played : played.filter((p) => p.players.some((pl) => pl.id === focus))

  return (
    <div>
      <PageHeader
        eyebrow={`${played.length} of ${totalPairs} pairs have played`}
        title="Partnerships"
        description="Every two-player combination, whichever order they were picked in. Ranked by winning percentage together."
      />

      <Tabs value={focus} onValueChange={setFocus} className="mb-5">
        <div className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
          <TabsList className="h-auto w-max gap-1 rounded-xl bg-muted p-1">
            <TabsTrigger value="all" className="rounded-lg px-3 py-1.5">
              All pairs
            </TabsTrigger>
            {players.map((p) => (
              <TabsTrigger key={p.id} value={p.id} className="rounded-lg px-3 py-1.5">
                {p.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
      </Tabs>

      {list.length === 0 ? (
        <EmptyState icon={<UsersRound />} title="No partnerships yet" description="Pairs appear here once they've played together." />
      ) : (
        <ol className="grid gap-3 md:grid-cols-2">
          {list.map((pair) => (
            <li
              key={pair.key}
              className={cn(
                'flex items-center gap-4 rounded-2xl border bg-card p-4',
                pair.rank === 1 && focus === 'all' && 'border-primary/40 bg-gradient-to-br from-accent/30 to-card',
              )}
            >
              <RankBadge rank={pair.rank} />
              <div className="flex -space-x-3">
                <PlayerAvatar player={pair.players[0]} />
                <PlayerAvatar player={pair.players[1]} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">
                  {pair.players[0].name} <span className="text-muted-foreground">&</span> {pair.players[1].name}
                </p>
                <p className="tabular text-xs text-muted-foreground">
                  {pair.matches} together · <span className="font-semibold text-win">{pair.wins}W</span>{' '}
                  <span className="text-loss">{pair.losses}L</span>
                </p>
                <WinBar value={pair.winPct} className="mt-2" />
              </div>
              <Pct value={pair.winPct} className="text-xl" />
            </li>
          ))}
        </ol>
      )}

      {unplayed.length > 0 && focus === 'all' && (
        <section className="mt-10" aria-labelledby="unplayed">
          <h2 id="unplayed" className="mb-3 font-display text-lg font-bold">
            Yet to team up <span className="tabular text-sm font-semibold text-muted-foreground">({unplayed.length})</span>
          </h2>
          <ul className="flex flex-wrap gap-2">
            {unplayed.map((pair) => (
              <li key={pair.key} className="inline-flex items-center gap-2 rounded-full border border-dashed bg-card py-1 pr-3 pl-1 text-sm">
                <span className="flex -space-x-2">
                  <PlayerAvatar player={pair.players[0]} size="xs" />
                  <PlayerAvatar player={pair.players[1]} size="xs" />
                </span>
                {pair.players[0].name} & {pair.players[1].name}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
