import { Link, createFileRoute } from '@tanstack/react-router'
import { Hourglass, Info, Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useLeague } from '@/lib/league/store'
import { computeLeaderboard, recentForm, MIN_MATCHES_TO_QUALIFY } from '@/lib/league/stats'
import type { PlayerStats, Ranked } from '@/lib/league/types'
import { EmptyState, FormDots, PageHeader, Pct, PlayerAvatar, RankBadge, SectionTitle, WinBar } from '@/components/league/bits'

export const Route = createFileRoute('/_app/leaderboard')({
  head: () => ({ meta: [{ title: 'All-Time Leaderboard · Badminton Cafe' }] }),
  component: Leaderboard,
})

function Podium({ top }: { top: Ranked<PlayerStats>[] }) {
  // Display order: 2nd, 1st, 3rd
  const order = [top[1], top[0], top[2]].filter(Boolean)
  return (
    <div className="court-lines rise-in mb-8 grid grid-cols-3 items-end gap-2 rounded-3xl px-3 pt-6 pb-0 text-sidebar-foreground sm:gap-4 sm:px-8">
      {order.map((s) => {
        const first = s === top[0]
        return (
          <Link
            key={s.player.id}
            to="/players/$playerId"
            params={{ playerId: s.player.id }}
            className="group flex flex-col items-center text-center"
          >
            <PlayerAvatar player={s.player} size={first ? 'xl' : 'lg'} className="ring-4 ring-court transition-transform group-hover:-translate-y-0.5 motion-reduce:transition-none" />
            <p className="mt-2 line-clamp-1 font-display text-sm font-bold sm:text-base">{s.player.name}</p>
            <Pct value={s.winPct} className={cn('text-accent', first ? 'text-2xl' : 'text-lg')} />
            <div
              className={cn(
                'mt-2 flex w-full items-start justify-center rounded-t-2xl pt-3 font-display font-extrabold',
                s.rank === 1 ? 'h-24 bg-gold text-[oklch(0.3_0.06_70)]' : s.rank === 2 ? 'h-16 bg-silver text-[oklch(0.3_0.02_240)]' : 'h-12 bg-bronze text-white',
              )}
            >
              <span className="text-2xl">{s.rank}</span>
            </div>
          </Link>
        )
      })}
    </div>
  )
}

function Leaderboard() {
  const { players, matches } = useLeague()
  const { qualified, unqualified } = computeLeaderboard(players, matches)

  return (
    <div>
      <PageHeader
        eyebrow="Since the first rally"
        title="All-time leaderboard"
        description={`Ranked by winning percentage. Players need at least ${MIN_MATCHES_TO_QUALIFY} matches to be ranked; equal percentages share a rank.`}
      />

      {qualified.length >= 3 && <Podium top={qualified.slice(0, 3)} />}

      <section aria-labelledby="ranked">
        <SectionTitle>
          <span id="ranked" className="flex items-center gap-2">
            <Trophy className="size-4 text-primary" aria-hidden /> Ranked players
          </span>
        </SectionTitle>
        {qualified.length === 0 ? (
          <EmptyState icon={<Trophy />} title="Nobody ranked yet" description={`Play ${MIN_MATCHES_TO_QUALIFY} matches to enter the table.`} />
        ) : (
          <div className="overflow-hidden rounded-2xl border bg-card">
            <div className="hidden grid-cols-[3rem_1fr_5rem_5rem_5rem_7rem_6rem] gap-2 border-b bg-muted/50 px-4 py-2.5 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase md:grid">
              <span>Rank</span>
              <span>Player</span>
              <span className="text-right">Played</span>
              <span className="text-right">Won</span>
              <span className="text-right">Lost</span>
              <span>Form</span>
              <span className="text-right">Win %</span>
            </div>
            <ol className="divide-y">
              {qualified.map((s) => (
                <li key={s.player.id}>
                  <Link
                    to="/players/$playerId"
                    params={{ playerId: s.player.id }}
                    className="grid grid-cols-[2.5rem_1fr_auto] items-center gap-x-3 gap-y-1 px-4 py-3 transition-colors hover:bg-muted/40 md:grid-cols-[3rem_1fr_5rem_5rem_5rem_7rem_6rem] md:gap-2"
                  >
                    <RankBadge rank={s.rank} />
                    <span className="flex min-w-0 items-center gap-3">
                      <PlayerAvatar player={s.player} size="sm" />
                      <span className="min-w-0">
                        <span className="block truncate font-semibold">
                          {s.player.name}
                          {!s.player.isActive && <span className="ml-1.5 text-xs font-normal text-muted-foreground">(inactive)</span>}
                        </span>
                        <span className="tabular block text-xs text-muted-foreground md:hidden">
                          {s.matches} played · {s.wins}W {s.losses}L
                        </span>
                      </span>
                    </span>
                    <span className="tabular hidden text-right md:block">{s.matches}</span>
                    <span className="tabular hidden text-right font-semibold text-win md:block">{s.wins}</span>
                    <span className="tabular hidden text-right text-loss md:block">{s.losses}</span>
                    <span className="hidden md:block">
                      <FormDots form={recentForm(s.player.id, matches)} />
                    </span>
                    <span className="text-right">
                      <Pct value={s.winPct} className="text-lg" />
                      <WinBar value={s.winPct} className="mt-1 ml-auto w-16" />
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
          </div>
        )}
      </section>

      <section aria-labelledby="unranked" className="mt-10">
        <SectionTitle>
          <span id="unranked" className="flex items-center gap-2">
            <Hourglass className="size-4 text-muted-foreground" aria-hidden /> Not yet qualified
          </span>
        </SectionTitle>
        {unqualified.length === 0 ? (
          <p className="rounded-2xl border border-dashed p-4 text-sm text-muted-foreground">Everyone has qualified. 🏸</p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {unqualified.map((s) => (
              <Link
                key={s.player.id}
                to="/players/$playerId"
                params={{ playerId: s.player.id }}
                className="flex items-center gap-3 rounded-2xl border bg-card p-4 transition-colors hover:bg-muted/40"
              >
                <PlayerAvatar player={s.player} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{s.player.name}</p>
                  <p className="tabular text-xs text-muted-foreground">
                    {s.matches} played · {s.wins}W {s.losses}L · <Pct value={s.winPct} className="font-semibold" />
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex flex-1 gap-1" aria-hidden>
                      {Array.from({ length: MIN_MATCHES_TO_QUALIFY }, (_, i) => (
                        <span key={i} className={cn('h-1.5 flex-1 rounded-full', i < s.matches ? 'bg-primary' : 'bg-muted')} />
                      ))}
                    </div>
                    <span className="text-[11px] font-semibold text-muted-foreground">
                      {MIN_MATCHES_TO_QUALIFY - s.matches} to go
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
        <p className="mt-4 flex items-start gap-1.5 text-xs text-muted-foreground">
          <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
          All-time statistics are continuous and include deactivated players' historical matches.
        </p>
      </section>
    </div>
  )
}
