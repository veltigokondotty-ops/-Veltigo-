import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, CalendarDays, Crown, Flame, Plus, Sparkles, Swords, Target, Trophy, UsersRound } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useLeague } from '@/lib/league/store'
import {
  computeDaily,
  computeLeaderboard,
  computePartnerships,
  computePlayerStats,
  currentStreak,
  matchDays,
  recentForm,
  MIN_MATCHES_TO_QUALIFY,
} from '@/lib/league/stats'
import { formatDayLabel, relativeDayLabel, todayKey } from '@/lib/league/time'
import { FormDots, Pct, PlayerAvatar, RankBadge, SectionTitle, StatTile, WinBar, EmptyState } from '@/components/league/bits'
import { MatchCard } from '@/components/league/match-card'

export const Route = createFileRoute('/_app/dashboard')({
  head: () => ({ meta: [{ title: 'Dashboard · Badminton Cafe' }] }),
  component: Dashboard,
})

function Dashboard() {
  const { players, matches, currentUser, playerById } = useLeague()
  const days = matchDays(matches)
  const today = todayKey()
  const spotlightDay = days.find((d) => d.dateKey === today)?.dateKey ?? days[0]?.dateKey ?? today
  const daily = computeDaily(players, matches, spotlightDay)
  const { qualified } = computeLeaderboard(players, matches)
  const { played: pairs } = computePartnerships(players, matches)
  const me = currentUser ? computePlayerStats([currentUser], matches)[0] : null
  const myRank = qualified.find((q) => q.player.id === currentUser?.id)?.rank
  const streak = currentUser ? currentStreak(currentUser.id, matches) : null
  const bestPair = pairs.find((p) => p.matches >= 3) ?? pairs[0]
  const isToday = spotlightDay === today

  return (
    <div className="grid gap-8">
      {/* Spotlight */}
      <section className="court-lines rise-in relative overflow-hidden rounded-3xl p-5 text-sidebar-foreground sm:p-8">
        <div className="pointer-events-none absolute -top-16 -right-16 size-56 rounded-full border-[18px] border-accent/10" aria-hidden />
        <p className="text-xs font-semibold tracking-[0.2em] text-accent uppercase">
          {isToday ? "Today's session" : `Latest session · ${relativeDayLabel(spotlightDay)}`}
        </p>
        <h1 className="mt-2 font-display text-3xl font-extrabold tracking-tight sm:text-5xl">
          Hello, {currentUser?.name.split(' ')[0]}.
        </h1>
        <p className="mt-1 text-sm opacity-75 sm:text-base">{formatDayLabel(spotlightDay)}</p>

        <div className="mt-6 grid gap-4 sm:grid-cols-[auto_1fr] sm:items-end">
          <div className="flex items-end gap-6">
            <div>
              <p className="tabular font-display text-5xl font-extrabold text-accent sm:text-6xl">{daily.totalMatches}</p>
              <p className="text-xs font-semibold tracking-wider uppercase opacity-70">Matches played</p>
            </div>
            <div className="h-14 w-px bg-sidebar-border" aria-hidden />
            <div className="min-w-0">
              <p className="mb-1.5 flex items-center gap-1 text-xs font-semibold tracking-wider uppercase opacity-70">
                <Crown className="size-3.5 text-gold" aria-hidden /> Player of the Day
              </p>
              {daily.playerOfTheDay.length > 0 ? (
                <div className="flex flex-wrap items-center gap-2">
                  {daily.playerOfTheDay.map((s) => (
                    <span key={s.player.id} className="inline-flex items-center gap-1.5 rounded-full bg-sidebar-accent py-1 pr-3 pl-1">
                      <PlayerAvatar player={s.player} size="xs" className="ring-0" />
                      <span className="text-sm font-bold">{s.player.name}</span>
                    </span>
                  ))}
                  <span className="text-xs opacity-70">
                    {daily.topWins} wins{daily.playerOfTheDay.length > 1 ? ' · joint' : ''}
                  </span>
                </div>
              ) : (
                <p className="text-sm opacity-70">No matches yet</p>
              )}
            </div>
          </div>
          <div className="flex gap-2 sm:justify-end">
            <Button asChild size="lg" className="h-11 rounded-xl bg-accent font-bold text-accent-foreground hover:bg-accent/90">
              <Link to="/add-match">
                <Plus aria-hidden /> Add match
              </Link>
            </Button>
            <Button asChild size="lg" variant="ghost" className="h-11 rounded-xl text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground">
              <Link to="/daily" search={{ date: spotlightDay }}>
                Day stats <ArrowRight aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* My numbers */}
      {me && (
        <section aria-labelledby="my-stats">
          <SectionTitle
            action={
              <Link to="/players/$playerId" params={{ playerId: me.player.id }} className="text-sm font-semibold text-primary hover:underline">
                My profile
              </Link>
            }
          >
            <span id="my-stats">Your numbers</span>
          </SectionTitle>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <StatTile label="Win rate" value={<Pct value={me.winPct} />} hint={`${me.wins}W · ${me.losses}L`} icon={<Target />} tone="lime" />
            <StatTile
              label="Rank"
              value={myRank ? `#${myRank}` : '—'}
              hint={myRank ? `of ${qualified.length} ranked` : `${Math.max(0, MIN_MATCHES_TO_QUALIFY - me.matches)} more to qualify`}
              icon={<Trophy />}
            />
            <StatTile label="Matches" value={me.matches} hint="All-time" icon={<Swords />} />
            <StatTile
              label="Streak"
              value={streak ? `${streak.count}${streak.type}` : '—'}
              hint={<FormDots form={recentForm(me.player.id, matches)} />}
              icon={<Flame />}
            />
          </div>
        </section>
      )}

      <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
        {/* Leaderboard preview */}
        <section aria-labelledby="top-ranked">
          <SectionTitle
            action={
              <Link to="/leaderboard" className="text-sm font-semibold text-primary hover:underline">
                Full table
              </Link>
            }
          >
            <span id="top-ranked">All-time top players</span>
          </SectionTitle>
          <div className="overflow-hidden rounded-2xl border bg-card">
            {qualified.length === 0 ? (
              <p className="p-6 text-sm text-muted-foreground">Players need {MIN_MATCHES_TO_QUALIFY} matches to be ranked.</p>
            ) : (
              <ol className="divide-y">
                {qualified.slice(0, 5).map((s) => (
                  <li key={s.player.id}>
                    <Link
                      to="/players/$playerId"
                      params={{ playerId: s.player.id }}
                      className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-muted/50"
                    >
                      <RankBadge rank={s.rank} />
                      <PlayerAvatar player={s.player} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold">{s.player.name}</p>
                        <WinBar value={s.winPct} className="mt-1.5 max-w-48" />
                      </div>
                      <div className="text-right">
                        <Pct value={s.winPct} className="text-lg" />
                        <p className="tabular text-xs text-muted-foreground">
                          {s.wins}–{s.losses}
                        </p>
                      </div>
                    </Link>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </section>

        <div className="grid content-start gap-8">
          {/* Partnership spotlight */}
          <section aria-labelledby="best-pair">
            <SectionTitle
              action={
                <Link to="/partnerships" className="text-sm font-semibold text-primary hover:underline">
                  All pairs
                </Link>
              }
            >
              <span id="best-pair">Top partnership</span>
            </SectionTitle>
            {bestPair ? (
              <div className="relative overflow-hidden rounded-2xl border bg-card p-5">
                <Sparkles className="absolute top-4 right-4 size-5 text-primary/30" aria-hidden />
                <div className="flex -space-x-3">
                  <PlayerAvatar player={bestPair.players[0]} size="lg" />
                  <PlayerAvatar player={bestPair.players[1]} size="lg" />
                </div>
                <p className="mt-3 font-display text-xl font-bold">
                  {bestPair.players[0].name} & {bestPair.players[1].name}
                </p>
                <div className="mt-3 flex items-end justify-between">
                  <p className="text-sm text-muted-foreground">
                    <span className="tabular font-semibold text-foreground">{bestPair.wins}</span> wins from{' '}
                    <span className="tabular font-semibold text-foreground">{bestPair.matches}</span> together
                  </p>
                  <Pct value={bestPair.winPct} className="text-2xl text-primary" />
                </div>
              </div>
            ) : (
              <EmptyState icon={<UsersRound />} title="No partnerships yet" />
            )}
          </section>

          <section aria-labelledby="league-totals">
            <h2 id="league-totals" className="sr-only">League totals</h2>
            <div className="grid grid-cols-2 gap-3">
              <StatTile label="Total matches" value={matches.length} icon={<Swords />} />
              <StatTile label="Match days" value={days.length} icon={<CalendarDays />} />
            </div>
          </section>
        </div>
      </div>

      {/* Recent matches */}
      <section aria-labelledby="recent">
        <SectionTitle
          action={
            <Link to="/matches" className="text-sm font-semibold text-primary hover:underline">
              Match history
            </Link>
          }
        >
          <span id="recent">Recent matches</span>
        </SectionTitle>
        {matches.length === 0 ? (
          <EmptyState icon={<Swords />} title="No matches recorded" description="Add the first match of the league." />
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {matches.slice(0, 6).map((m) => (
              <MatchCard key={m.id} match={m} playerById={playerById} highlightId={currentUser?.id} />
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
