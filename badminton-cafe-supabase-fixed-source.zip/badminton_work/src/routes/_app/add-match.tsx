import * as React from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { CheckCircle2, Info } from 'lucide-react'
import { toast } from 'sonner'
import { useLeague } from '@/lib/league/store'
import type { Match } from '@/lib/league/types'
import { PageHeader, EmptyState } from '@/components/league/bits'
import { MatchForm } from '@/components/league/match-form'
import { MatchCard } from '@/components/league/match-card'
import { winningTeam } from '@/lib/league/stats'

export const Route = createFileRoute('/_app/add-match')({
  head: () => ({ meta: [{ title: 'Add Match · Badminton Cafe' }] }),
  component: AddMatch,
})

function AddMatch() {
  const { activePlayers, playerById, addMatch } = useLeague()
  const [saved, setSaved] = React.useState<Match[]>([])

  return (
    <div>
      <PageHeader
        eyebrow="Doubles · 2 vs 2"
        title="Add a match"
        description="Pick four different players, then tap the team that won. No scores needed."
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <section className="rounded-3xl border bg-card p-4 sm:p-6">
          {activePlayers.length < 4 ? (
            <EmptyState
              icon={<Info />}
              title="Not enough active players"
              description="A doubles match needs at least four active players."
            />
          ) : (
            <MatchForm
              selectable={activePlayers}
              playerById={playerById}
              onSubmit={async (input) => {
                const m = await addMatch(input)
                setSaved((s) => [m, ...s].slice(0, 3))
                const w = winningTeam(m).map((id) => playerById(id)?.name).join(' & ')
                toast.success('Match saved', { description: `${w} take the win. Stats updated.` })
              }}
            />
          )}
        </section>

        <aside className="grid content-start gap-4">
          <div className="rounded-2xl border bg-secondary/60 p-4 text-sm">
            <p className="mb-2 flex items-center gap-1.5 font-display font-bold">
              <Info className="size-4 text-primary" aria-hidden /> How selection works
            </p>
            <ul className="grid gap-1.5 text-muted-foreground">
              <li>Each pick disappears from the lists that follow it.</li>
              <li>Change an earlier pick and later lists update on their own.</li>
              <li>Only active players can be picked for new matches.</li>
              <li>Times are recorded in India Standard Time.</li>
            </ul>
          </div>
          {saved.length > 0 && (
            <div>
              <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-win">
                <CheckCircle2 className="size-4" aria-hidden /> Saved this session
              </p>
              <div className="grid gap-2">
                {saved.map((m) => (
                  <MatchCard key={m.id} match={m} playerById={playerById} />
                ))}
              </div>
              <Link to="/matches" className="mt-2 inline-block text-sm font-semibold text-primary hover:underline">
                View match history
              </Link>
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}
