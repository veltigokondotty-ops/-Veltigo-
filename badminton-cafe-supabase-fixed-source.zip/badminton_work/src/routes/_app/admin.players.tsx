import * as React from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { KeyRound, Lock, Pencil, ShieldAlert, ShieldCheck, Smartphone, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { maskMobile, normalizeMobile, useLeague } from '@/lib/league/store'
import { computePlayerStats } from '@/lib/league/stats'
import type { Player } from '@/lib/league/types'
import { EmptyState, PageHeader, PlayerAvatar } from '@/components/league/bits'

export const Route = createFileRoute('/_app/admin/players')({
  head: () => ({ meta: [{ title: 'Player Management · Badminton Cafe' }] }),
  component: PlayerManagement,
})

type DialogState = { mode: 'add' } | { mode: 'edit'; player: Player } | null

function PlayerDialog({ state, onClose }: { state: DialogState; onClose: () => void }) {
  const { addPlayer, updatePlayer, isDuplicateMobile } = useLeague()
  const editing = state?.mode === 'edit' ? state.player : null
  const [name, setName] = React.useState('')
  const [mobile, setMobile] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [pending, setPending] = React.useState(false)

  React.useEffect(() => {
    setName(editing?.name ?? '')
    setMobile(editing?.mobile ?? '')
    setPassword('')
    setErrors({})
  }, [state, editing])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    const next: Record<string, string> = {}
    const digits = normalizeMobile(mobile)
    if (name.trim().length < 2) next.name = 'Enter the player’s name.'
    if (!editing || mobile) {
      if (!/^[6-9]\d{9}$/.test(digits)) next.mobile = 'Enter a valid 10-digit Indian mobile number.'
      else if (isDuplicateMobile(digits, editing?.id)) next.mobile = 'This mobile number is already registered to another player.'
    }
    if (!editing && password.length < 8) next.password = 'Use at least 8 characters.'
    setErrors(next)
    if (Object.keys(next).length) return

    setPending(true)
    try {
      if (editing) {
        await updatePlayer(editing.id, { name, mobile: digits })
        toast.success('Player updated', { description: name.trim() })
      } else {
        const p = await addPlayer({ name, mobile: digits, password })
        toast.success(`${p.name} added`, { description: 'Active now — they can be selected for new matches.' })
      }
      onClose()
    } catch (err) { setErrors({ form: err instanceof Error ? err.message : 'Unable to save player.' }) }
    finally { setPending(false) }
  }

  return (
    <Dialog open={Boolean(state)} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{editing ? `Edit ${editing.name}` : 'Add a new player'}</DialogTitle>
          <DialogDescription>
            {editing
              ? 'Update the player’s name or mobile number. Their match history stays intact.'
              : 'Creates the player and their login. They sign in with this mobile number and password.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4" noValidate>
          <div className="grid gap-1.5">
            <Label htmlFor="player-name">Name</Label>
            <Input id="player-name" value={name} onChange={(e) => setName(e.target.value)} aria-invalid={Boolean(errors.name)} className="h-11 rounded-xl" autoComplete="off" />
            {errors.name && <p className="text-xs font-medium text-destructive">{errors.name}</p>}
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="player-mobile">Mobile number</Label>
            <div className="relative">
              <Smartphone className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <Input
                id="player-mobile"
                type="tel"
                inputMode="numeric"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder={editing && !editing.mobile ? `Keep current (${maskMobile(editing)})` : '10-digit number'}
                aria-invalid={Boolean(errors.mobile)}
                className="tabular h-11 rounded-xl pl-9"
                autoComplete="off"
              />
            </div>
            {errors.mobile && <p className="text-xs font-medium text-destructive">{errors.mobile}</p>}
          </div>
          {!editing && (
            <div className="grid gap-1.5">
              <Label htmlFor="player-password">Initial password</Label>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <Input
                  id="player-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  aria-invalid={Boolean(errors.password)}
                  className="h-11 rounded-xl pl-9"
                  autoComplete="new-password"
                />
              </div>
              {errors.password ? (
                <p className="text-xs font-medium text-destructive">{errors.password}</p>
              ) : (
                <p className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Lock className="size-3" aria-hidden /> Sent once to the secure server and never stored in the app.
                </p>
              )}
            </div>
          )}
          {errors.form && <p role="alert" className="text-sm text-destructive">{errors.form}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={pending}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>{pending ? 'Saving…' : editing ? 'Save changes' : 'Create player'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function PlayerManagement() {
  const { players, matches, isAdmin, currentUser, setPlayerActive } = useLeague()
  const [dialog, setDialog] = React.useState<DialogState>(null)

  if (!isAdmin) {
    return (
      <EmptyState
        icon={<ShieldAlert />}
        title="Super Admin only"
        description="Only the Super Admin can add, edit or deactivate players."
        action={
          <Link to="/players" className="text-sm font-semibold text-primary hover:underline">
            View player profiles
          </Link>
        }
      />
    )
  }

  const stats = new Map(computePlayerStats(players, matches).map((s) => [s.player.id, s]))
  const activeCount = players.filter((p) => p.isActive).length

  return (
    <div>
      <PageHeader
        eyebrow="Super Admin"
        title="Player management"
        description={`${activeCount} active · ${players.length - activeCount} inactive. Deactivated players keep all their history and statistics but can't be picked for new matches.`}
        actions={
          <Button size="lg" className="rounded-xl" onClick={() => setDialog({ mode: 'add' })}>
            <UserPlus aria-hidden /> Add player
          </Button>
        }
      />

      <ul className="grid gap-2">
        {players.map((p) => {
          const s = stats.get(p.id)
          const isSelf = p.id === currentUser?.id
          return (
            <li key={p.id} className={cn('flex flex-wrap items-center gap-3 rounded-2xl border bg-card p-3 sm:flex-nowrap sm:p-4', !p.isActive && 'bg-muted/50')}>
              <PlayerAvatar player={p} />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1.5 truncate font-semibold">
                  {p.name}
                  {p.role === 'super_admin' && (
                    <span className="inline-flex items-center gap-1 rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-bold tracking-wider text-primary uppercase">
                      <ShieldCheck className="size-3" aria-hidden /> Super Admin
                    </span>
                  )}
                </p>
                <p className="tabular text-xs text-muted-foreground">
                  {maskMobile(p)} · {s?.matches ?? 0} matches
                </p>
              </div>
              <div className="ml-auto flex items-center gap-3">
                <label className="flex items-center gap-2 text-xs font-semibold">
                  <Switch
                    checked={p.isActive}
                    disabled={isSelf}
                    onCheckedChange={(v) => {
                      void setPlayerActive(p.id, v).then(() => toast.success(v ? `${p.name} activated` : `${p.name} deactivated`, { description: v ? 'Available for new matches.' : 'History and statistics are kept.' })).catch((err: unknown) => toast.error(err instanceof Error ? err.message : 'Unable to update player.'))
                    }}
                    aria-label={`${p.name} active`}
                  />
                  <span className={cn('w-14', p.isActive ? 'text-win' : 'text-muted-foreground')}>{p.isActive ? 'Active' : 'Inactive'}</span>
                </label>
                <Button variant="outline" size="icon-sm" aria-label={`Edit ${p.name}`} onClick={() => setDialog({ mode: 'edit', player: p })}>
                  <Pencil aria-hidden />
                </Button>
              </div>
            </li>
          )
        })}
      </ul>

      <PlayerDialog state={dialog} onClose={() => setDialog(null)} />
    </div>
  )
}
