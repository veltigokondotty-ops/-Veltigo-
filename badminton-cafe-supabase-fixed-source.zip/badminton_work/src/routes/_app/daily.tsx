import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { CalendarDays, ChevronLeft, ChevronRight, Crown, Swords } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useLeague } from '@/lib/league/store'
import { computeDaily, matchDays } from '@/lib/league/stats'
import { formatDayLabel, isDateKey, relativeDayLabel, shiftDateKey, todayKey } from '@/lib/league/time'
import { EmptyState, PageHeader, Pct, PlayerAvatar, RankBadge, SectionTitle, StatTile, WinBar } from '@/components/league/bits'
import { MatchCard } from '@/components/league/match-card'

export const Route = createFileRoute('/_app/daily')({
  validateSearch: (search: Record<string, unknown>): { date?: string } =>
    isDateKey(search.date) ? { date: search.date } : {},
  head: () => ({ meta: [{ title: 'Daily Performance · Badminton Cafe' }] }),
  component: Daily,
})

function Daily() {
  const { players, matches, playerById } = useLeague()
  const navigate = useNavigate({ from: '/daily' })
  const { date } = Route.useSearch()
  const today = todayKey()
  const days = matchDays(matches)
  const dateKey = date ?? today
  const daily = computeDaily(players, matches, dateKey)
  const go = (d: string) => navigate({ search: { date: d } })

  const prevDay = days.find((d) => d.dateKey < dateKey)?.dateKey
  const nextDay = [...days].reverse().find((d) => d.dateKey > dateKey)?.dateKey

  return (
    <div>
      <PageHeader
        eyebrow="Asia/Kolkata · IST"
        title="Daily performance"
        description="Each day stands on its own — separate from the all-time leaderboard."
      />

      {/* Date controls */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Button variant="outline" size="icon" aria-label="Previous day" onClick={() => go(shiftDateKey(dateKey, -1))} className="rounded-xl">
          <ChevronLeft aria-hidden />
        </Button>
        <div className="relative">
          <CalendarDays className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-primary" aria-hidden />
          <Input
            type="date"
            aria-label="Pick a date"
            value={dateKey}
            max={today}
            onChange={(e) => isDateKey(e.target.value) && go(e.target.value)}
            className="h-9 w-44 rounded-xl bg-card pl-9 font-semibold"
          />
        </div>
        <Button
          variant="outline"
          size="icon"
          aria-label="Next day"
          disabled={dateKey >= today}
          onClick={() => go(shiftDateKey(dateKey, 1))}
          className="rounded-xl"
        >
          <ChevronRight aria-hidden />
        </Button>
        {dateKey !== today && (
          <Button variant="ghost" onClick={() => go(today)} className="rounded-xl">
            Today
          </Button>
        )}
      </div>

      {/* Recent match days */}
      <div className="-mx-4 mb-6 overflow-x-auto px-4 sm:mx-0 sm:px-0">
        <div className="flex gap-2 pb-1">
          {days.slice(0, 14).map((d) => (
            <button
              key={d.dateKey}
              type="button"
              onClick={() => go(d.dateKey)}
              aria-pressed={d.dateKey === dateKey}
              className={cn(
                'shrink-0 rounded-xl border px-3 py-2 text-left transition-colors',
                d.dateKey === dateKey ? 'border-primary bg-primary text-primary-foreground' : 'bg-card hover:border-primary/40',
              )}
            >
              <span className="block text-xs font-bold">{relativeDayLabel(d.dateKey)}</span>
              <span className="tabular block text-[11px] opacity-70">{d.count} matches</span>
            </button>
          ))}
        </div>
      </div>

      <h2 className="mb-4 font-display text-xl font-bold">{formatDayLabel(dateKey)}</h2>

      {daily.totalMatches === 0 ? (
        <EmptyState
          icon={<Swords />}
          title="No matches on this day"
          description="Pick another date, or jump to the nearest day with matches."
          action={
            <div className="flex gap-2">
              {prevDay && (
                <Button variant="outline" onClick={() => go(prevDay)} className="rounded-xl">
                  <ChevronLeft aria-hidden /> {relativeDayLabel(prevDay)}
                </Button>
              )}
              {nextDay && (
                <Button variant="outline" onClick={() => go(nextDay)} className="rounded-xl">
                  {relativeDayLabel(nextDay)} <ChevronRight aria-hidden />
                </Button>
              )}
            </div>
          }
        />
      ) : (
        <div className="grid gap-8">
          <div className="grid gap-3 sm:grid-cols-[1.4fr_1fr_1fr]">
            {/* Player of the Day */}
            <div className="court-lines rise-in relative overflow-hidden rounded-2xl p-5 text-sidebar-foreground sm:row-span-1">
              <p className="flex items-center gap-1.5 text-xs font-semibold tracking-[0.16em] text-accent uppercase">
                <Crown className="size-4 text-gold" aria-hidden />
                {daily.playerOfTheDay.length > 1 ? 'Joint Players of the Day' : 'Player of the Day'}
              </p>
              <div className="mt-3 flex flex-wrap gap-4">
                {daily.playerOfTheDay.map((s) => (
                  <Link key={s.player.id} to="/players/$playerId" params={{ playerId: s.player.id }} className="flex items-center gap-3">
                    <PlayerAvatar player={s.player} size="lg" className="ring-4 ring-gold/70" />
                    <span>
                      <span className="block font-display text-xl font-extrabold">{s.player.name}</span>
                      <span className="tabular block text-xs opacity-75">
                        {s.wins}W · {s.losses}L · <Pct value={s.winPct} />
                      </span>
                    </span>
                  </Link>
                ))}
              </div>
              <p className="mt-3 text-xs opacity-60">Most individual wins of the day ({daily.topWins}).</p>
            </div>
            <StatTile label="Matches" value={daily.totalMatches} hint="Played this day" icon={<Swords />} />
            <StatTile label="Players" value={daily.ranking.length} hint="Took the court" icon={<CalendarDays />} />
          </div>

          <section aria-labelledby="daily-ranking">
            <SectionTitle>
              <span id="daily-ranking">Daily rankings</span>
            </SectionTitle>
            <div className="overflow-hidden rounded-2xl border bg-card">
              <div className="grid grid-cols-[2.5rem_1fr_3rem_3rem_3rem_4.5rem] gap-2 border-b bg-muted/50 px-4 py-2.5 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
                <span>#</span>
                <span>Player</span>
                <span className="text-right">P</span>
                <span className="text-right">W</span>
                <span className="text-right">L</span>
                <span className="text-right">Win %</span>
              </div>
              <ol className="divide-y">
                {daily.ranking.map((s) => (
                  <li key={s.player.id} className="grid grid-cols-[2.5rem_1fr_3rem_3rem_3rem_4.5rem] items-center gap-2 px-4 py-3">
                    <RankBadge rank={s.rank} className="size-7" />
                    <span className="flex min-w-0 items-center gap-2">
                      <PlayerAvatar player={s.player} size="xs" />
                      <span className="truncate font-semibold">{s.player.name}</span>
                      {daily.playerOfTheDay.some((p) => p.player.id === s.player.id) && (
                        <Crown className="size-3.5 shrink-0 text-gold" aria-label="Player of the Day" />
                      )}
                    </span>
                    <span className="tabular text-right">{s.matches}</span>
                    <span className="tabular text-right font-semibold text-win">{s.wins}</span>
                    <span className="tabular text-right text-loss">{s.losses}</span>
                    <span className="text-right">
                      <Pct value={s.winPct} />
                      <WinBar value={s.winPct} className="mt-1" />
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          </section>

          <section aria-labelledby="daily-matches">
            <SectionTitle>
              <span id="daily-matches">Matches</span>
            </SectionTitle>
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {daily.matches.map((m) => (
                <MatchCard key={m.id} match={m} playerById={playerById} showDate={false} />
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  )
}
