import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowLeft, Crown, Flame, ShieldCheck, Swords, Target, Trophy, UserRoundX } from 'lucide-react'
import { useLeague } from '@/lib/league/store'
import {
  computeDaily,
  computeLeaderboard,
  computePartnerships,
  computePlayerStats,
  currentStreak,
  matchDays,
  matchPlayers,
  recentForm,
  MIN_MATCHES_TO_QUALIFY,
} from '@/lib/league/stats'
import { EmptyState, FormDots, Pct, PlayerAvatar, SectionTitle, StatTile, WinBar } from '@/components/league/bits'
import { MatchCard } from '@/components/league/match-card'

export const Route = createFileRoute('/_app/players/$playerId')({
  head: () => ({ meta: [{ title: 'Player · Badminton Cafe' }] }),
  component: PlayerProfile,
})

function PlayerProfile() {
  const { playerId } = Route.useParams()
  const { players, matches, playerById } = useLeague()
  const player = playerById(playerId)

  if (!player) {
    return (
      <EmptyState
        icon={<UserRoundX />}
        title="Player not found"
        action={
          <Link to="/players" className="text-sm font-semibold text-primary hover:underline">
            Back to players
          </Link>
        }
      />
    )
  }

  const stats = computePlayerStats([player], matches)[0]
  const { qualified } = computeLeaderboard(players, matches)
  const rank = qualified.find((q) => q.player.id === player.id)?.rank
  const myPairs = computePartnerships(players, matches).played.filter((p) => p.players.some((x) => x.id === player.id))
  const streak = currentStreak(player.id, matches)
  const myMatches = matches.filter((m) => matchPlayers(m).includes(player.id))
  const potdCount = matchDays(matches).filter((d) =>
    computeDaily(players, matches, d.dateKey).playerOfTheDay.some((s) => s.player.id === player.id),
  ).length

  return (
    <div className="grid gap-8">
      <div>
        <Link to="/players" className="mb-4 inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-4" aria-hidden /> All players
        </Link>
        <section className="court-lines rise-in flex flex-col gap-5 rounded-3xl p-5 text-sidebar-foreground sm:flex-row sm:items-center sm:p-8">
          <PlayerAvatar player={player} size="xl" className="ring-4 ring-accent/60" />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-xs font-semibold tracking-[0.16em] text-accent uppercase">
              {player.role === 'super_admin' ? (
                <>
                  <ShieldCheck className="size-3.5" aria-hidden /> Super Admin
                </>
              ) : (
                'Member'
              )}
              {!player.isActive && ' · Inactive'}
            </p>
            <h1 className="font-display text-4xl font-extrabold tracking-tight">{player.name}</h1>
            <p className="mt-1 text-sm opacity-75">
              {rank ? `Ranked #${rank} all-time` : `${Math.max(0, MIN_MATCHES_TO_QUALIFY - stats.matches)} more matches to qualify for the ranking`}
            </p>
          </div>
          <div className="sm:text-right">
            <Pct value={stats.winPct} className="text-5xl text-accent" />
            <p className="text-xs font-semibold tracking-wider uppercase opacity-70">All-time win rate</p>
          </div>
        </section>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Played" value={stats.matches} icon={<Swords />} />
        <StatTile label="Record" value={`${stats.wins}–${stats.losses}`} hint="Wins – losses" icon={<Target />} />
        <StatTile label="Streak" value={streak ? `${streak.count}${streak.type}` : '—'} hint={<FormDots form={recentForm(player.id, matches)} />} icon={<Flame />} />
        <StatTile label="Player of the Day" value={potdCount} hint="Times, incl. joint" icon={<Crown />} tone="lime" />
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr]">
        <section aria-labelledby="partners">
          <SectionTitle>
            <span id="partners">Partners</span>
          </SectionTitle>
          {myPairs.length === 0 ? (
            <EmptyState icon={<Trophy />} title="No partnerships yet" />
          ) : (
            <ol className="divide-y overflow-hidden rounded-2xl border bg-card">
              {myPairs.map((pair) => {
                const partner = pair.players[0].id === player.id ? pair.players[1] : pair.players[0]
                return (
                  <li key={pair.key} className="flex items-center gap-3 px-4 py-3">
                    <PlayerAvatar player={partner} size="sm" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">{partner.name}</p>
                      <p className="tabular text-xs text-muted-foreground">
                        {pair.matches} together · {pair.wins}W {pair.losses}L
                      </p>
                      <WinBar value={pair.winPct} className="mt-1.5" />
                    </div>
                    <Pct value={pair.winPct} />
                  </li>
                )
              })}
            </ol>
          )}
        </section>

        <section aria-labelledby="player-matches">
          <SectionTitle>
            <span id="player-matches">Recent matches</span>
          </SectionTitle>
          {myMatches.length === 0 ? (
            <EmptyState icon={<Swords />} title="No matches yet" />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              {myMatches.slice(0, 8).map((m) => (
                <MatchCard key={m.id} match={m} playerById={playerById} highlightId={player.id} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
