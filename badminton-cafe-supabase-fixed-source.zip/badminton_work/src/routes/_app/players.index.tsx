import { Link, createFileRoute } from '@tanstack/react-router'
import { ChevronRight, ShieldCheck } from 'lucide-react'
import { useLeague } from '@/lib/league/store'
import { computeLeaderboard, computePlayerStats, recentForm } from '@/lib/league/stats'
import { FormDots, PageHeader, Pct, PlayerAvatar } from '@/components/league/bits'

export const Route = createFileRoute('/_app/players/')({
  head: () => ({ meta: [{ title: 'Player Profiles · Badminton Cafe' }] }),
  component: Players,
})

function Players() {
  const { players, matches } = useLeague()
  const stats = computePlayerStats(players, matches)
  const { qualified } = computeLeaderboard(players, matches)
  const rankOf = new Map(qualified.map((q) => [q.player.id, q.rank]))
  const sorted = [...stats].sort((a, b) => Number(b.player.isActive) - Number(a.player.isActive) || a.player.name.localeCompare(b.player.name))

  return (
    <div>
      <PageHeader eyebrow={`${players.filter((p) => p.isActive).length} active players`} title="Player profiles" description="Career numbers, form and favourite partners for everyone in the group." />
      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {sorted.map((s) => (
          <li key={s.player.id}>
            <Link
              to="/players/$playerId"
              params={{ playerId: s.player.id }}
              className="group flex h-full flex-col rounded-2xl border bg-card p-4 transition-all hover:-translate-y-0.5 hover:shadow-md motion-reduce:transition-none"
            >
              <div className="flex items-center gap-3">
                <PlayerAvatar player={s.player} size="lg" />
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1.5 truncate font-display text-lg font-bold">
                    {s.player.name}
                    {s.player.role === 'super_admin' && <ShieldCheck className="size-4 text-primary" aria-label="Super Admin" />}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {s.player.isActive ? (rankOf.has(s.player.id) ? `Ranked #${rankOf.get(s.player.id)}` : 'Not yet ranked') : 'Inactive'}
                  </p>
                </div>
                <ChevronRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5" aria-hidden />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-muted/60 p-3 text-center">
                <div>
                  <p className="tabular font-display text-lg font-bold">{s.matches}</p>
                  <p className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">Played</p>
                </div>
                <div>
                  <p className="tabular font-display text-lg font-bold text-win">{s.wins}</p>
                  <p className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">Won</p>
                </div>
                <div>
                  <Pct value={s.winPct} className="text-lg" />
                  <p className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">Win %</p>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Last 5</span>
                <FormDots form={recentForm(s.player.id, matches)} />
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
