import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { MoreHorizontal, Pencil, Search, ShieldCheck, Swords, Trash2, TriangleAlert } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLeague } from '@/lib/league/store'
import type { Match } from '@/lib/league/types'
import { formatDayLabel, istDateKey } from '@/lib/league/time'
import { matchPlayers } from '@/lib/league/stats'
import { EmptyState, PageHeader } from '@/components/league/bits'
import { MatchCard } from '@/components/league/match-card'
import { MatchForm } from '@/components/league/match-form'

export const Route = createFileRoute('/_app/matches')({
  head: () => ({ meta: [{ title: 'Match History · Badminton Cafe' }] }),
  component: MatchHistory,
})

function MatchHistory() {
  const { matches, players, playerById, isAdmin, activePlayers, updateMatch, deleteMatch } = useLeague()
  const [playerFilter, setPlayerFilter] = React.useState('all')
  const [query, setQuery] = React.useState('')
  const [editing, setEditing] = React.useState<Match | null>(null)
  const [deleting, setDeleting] = React.useState<Match | null>(null)

  const filtered = matches.filter((m) => {
    if (playerFilter !== 'all' && !matchPlayers(m).includes(playerFilter)) return false
    if (query.trim()) {
      const q = query.trim().toLowerCase()
      return matchPlayers(m).some((id) => playerById(id)?.name.toLowerCase().includes(q))
    }
    return true
  })

  const groups = new Map<string, Match[]>()
  for (const m of filtered) {
    const k = istDateKey(m.playedAt)
    groups.set(k, [...(groups.get(k) ?? []), m])
  }

  // Editing keeps the match's original players selectable even if they have since been deactivated.
  const editSelectable = editing
    ? [...activePlayers, ...matchPlayers(editing).map((id) => playerById(id)!).filter((p) => p && !p.isActive)]
    : activePlayers

  return (
    <div>
      <PageHeader
        eyebrow={`${matches.length} matches recorded`}
        title="Match history"
        description="Every doubles match, newest first. Times shown in IST."
        actions={
          isAdmin ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-primary">
              <ShieldCheck className="size-3.5" aria-hidden /> Super Admin can edit & delete
            </span>
          ) : undefined
        }
      />

      <div className="mb-6 grid gap-2 sm:grid-cols-[1fr_14rem]">
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by player name"
            aria-label="Search matches by player name"
            className="h-11 rounded-xl bg-card pl-9"
          />
        </div>
        <Select value={playerFilter} onValueChange={setPlayerFilter}>
          <SelectTrigger className="h-11 w-full rounded-xl bg-card" aria-label="Filter by player">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All players</SelectItem>
            {players.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.name}
                {!p.isActive && ' (inactive)'}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={<Swords />} title="No matches found" description="Try a different player or clear the search." />
      ) : (
        <div className="grid gap-8">
          {[...groups.entries()].map(([day, list]) => (
            <section key={day} aria-label={formatDayLabel(day)}>
              <div className="sticky top-[68px] z-10 -mx-1 mb-3 flex items-baseline justify-between bg-background/90 px-1 py-2 backdrop-blur lg:top-0">
                <h2 className="font-display text-base font-bold">{formatDayLabel(day)}</h2>
                <span className="tabular text-xs font-semibold text-muted-foreground">{list.length} matches</span>
              </div>
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {list.map((m) => (
                  <MatchCard
                    key={m.id}
                    match={m}
                    playerById={playerById}
                    showDate={false}
                    highlightId={playerFilter !== 'all' ? playerFilter : undefined}
                    actions={
                      isAdmin ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" aria-label="Match actions" className="-my-1">
                              <MoreHorizontal aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onSelect={() => setEditing(m)}>
                              <Pencil aria-hidden /> Edit match
                            </DropdownMenuItem>
                            <DropdownMenuItem variant="destructive" onSelect={() => setDeleting(m)}>
                              <Trash2 aria-hidden /> Delete permanently
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : undefined
                    }
                  />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {/* Edit (Super Admin) */}
      <Dialog open={Boolean(editing)} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Edit match</DialogTitle>
            <DialogDescription>Change the players, winner or time. All statistics update immediately.</DialogDescription>
          </DialogHeader>
          {editing && (
            <MatchForm
              key={editing.id}
              selectable={editSelectable}
              playerById={playerById}
              initial={{ slots: [...editing.teamA, ...editing.teamB], winner: editing.winner, playedAt: editing.playedAt }}
              submitLabel="Save changes"
              onCancel={() => setEditing(null)}
              onSubmit={async (input) => {
                await updateMatch(editing.id, input)
                setEditing(null)
                toast.success('Match updated', { description: 'Leaderboard, daily and partnership stats refreshed.' })
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Permanent delete confirmation (Super Admin) */}
      <Dialog open={Boolean(deleting)} onOpenChange={(o) => !o && setDeleting(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <span className="mb-2 inline-flex size-11 items-center justify-center rounded-full bg-destructive/10 text-destructive">
              <TriangleAlert className="size-5" aria-hidden />
            </span>
            <DialogTitle className="font-display text-xl">Delete this match permanently?</DialogTitle>
            <DialogDescription>
              This can't be undone — there is no recycle bin. Wins, losses, rankings and partnership stats will be recalculated
              without it.
            </DialogDescription>
          </DialogHeader>
          {deleting && <MatchCard match={deleting} playerById={playerById} />}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleting(null)}>
              Keep match
            </Button>
            <Button
              variant="destructive"
              onClick={async () => {
                try { if (deleting) await deleteMatch(deleting.id); setDeleting(null); toast.success('Match deleted permanently', { description: 'All statistics have been refreshed.' }) }
                catch (err) { toast.error(err instanceof Error ? err.message : 'Unable to delete match.') }
              }}
            >
              <Trash2 aria-hidden /> Delete permanently
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
