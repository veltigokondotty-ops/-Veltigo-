import * as React from 'react'
import { Link, Outlet, createFileRoute, useNavigate, useRouterState } from '@tanstack/react-router'
import { LogOut, Menu, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { useLeague } from '@/lib/league/store'
import { PlayerAvatar, ShuttleMark } from '@/components/league/bits'
import { bottomNav, navItems } from '@/components/league/nav'

export const Route = createFileRoute('/_app')({
  component: AppLayout,
})

function Brand({ className }: { className?: string }) {
  return (
    <Link to="/dashboard" className={cn('flex items-center gap-2.5', className)}>
      <span className="inline-flex size-9 items-center justify-center rounded-xl bg-accent text-court shadow-[inset_0_-2px_0_oklch(0_0_0/0.12)]">
        <ShuttleMark className="size-6" />
      </span>
      <span className="leading-none">
        <span className="block font-display text-lg font-extrabold tracking-tight">Badminton Cafe</span>
        <span className="block text-[10px] font-semibold tracking-[0.18em] uppercase opacity-60">Play • Compete • Connect</span>
      </span>
    </Link>
  )
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const { isAdmin } = useLeague()
  const pathname = useRouterState({ select: (s) => s.location.pathname })
  return (
    <nav aria-label="Main" className="grid gap-0.5">
      {navItems
        .filter((i) => !i.adminOnly || isAdmin)
        .map((item) => {
          const active = pathname === item.to || pathname.startsWith(item.to + '/')
          const Icon = item.icon
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              className={cn(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors motion-reduce:transition-none',
                active
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                  : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground',
              )}
            >
              <Icon className="size-[18px]" aria-hidden />
              {item.label}
              {item.adminOnly && (
                <span className={cn('ml-auto rounded-md px-1.5 py-0.5 text-[9px] tracking-wider uppercase', active ? 'bg-court/15' : 'bg-sidebar-accent')}>
                  Admin
                </span>
              )}
            </Link>
          )
        })}
    </nav>
  )
}

function UserFooter() {
  const { currentUser, signOut } = useLeague()
  const navigate = useNavigate()
  if (!currentUser) return null
  return (
    <div className="flex items-center gap-3 rounded-xl p-2">
      <PlayerAvatar player={currentUser} size="sm" className="ring-sidebar" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-bold">{currentUser.name}</p>
        <p className="text-xs opacity-60">{currentUser.role === 'super_admin' ? 'Super Admin' : 'Member'}</p>
      </div>
      <Button
        variant="ghost"
        size="icon-sm"
        aria-label="Sign out"
        className="text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
        onClick={() => {
          signOut()
          navigate({ to: '/' })
        }}
      >
        <LogOut aria-hidden />
      </Button>
    </div>
  )
}

function AppLayout() {
  const { currentUser } = useLeague()
  const [moreOpen, setMoreOpen] = React.useState(false)
  const pathname = useRouterState({ select: (s) => s.location.pathname })

  if (!currentUser) {
    return (
      <div className="court-lines flex min-h-dvh items-center justify-center p-6 text-sidebar-foreground">
        <div className="max-w-sm text-center">
          <ShuttleMark className="mx-auto mb-4 size-12 text-accent" />
          <h1 className="font-display text-2xl font-extrabold">You're signed out</h1>
          <p className="mt-2 text-sm opacity-75">Sign in with your mobile number to see the league.</p>
          <Button asChild size="lg" className="mt-6 rounded-xl bg-accent text-accent-foreground hover:bg-accent/90">
            <Link to="/">Go to sign in</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[17rem_1fr]">
      {/* Desktop sidebar */}
      <aside className="court-lines sticky top-0 hidden h-dvh flex-col gap-6 p-4 text-sidebar-foreground lg:flex">
        <Brand className="px-2 pt-2" />
        <div className="flex-1 overflow-y-auto">
          <NavList />
        </div>
        <UserFooter />
      </aside>

      {/* Mobile top bar */}
      <header className="court-lines sticky top-0 z-30 flex items-center justify-between px-4 py-3 text-sidebar-foreground lg:hidden">
        <Brand />
        <Button
          variant="ghost"
          size="icon"
          aria-label="Open menu"
          className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
          onClick={() => setMoreOpen(true)}
        >
          <Menu aria-hidden />
        </Button>
      </header>

      <main className="min-w-0 pb-28 lg:pb-10">
        <div className="mx-auto w-full max-w-content px-4 pt-6 sm:px-6 lg:pt-10">
          <Outlet />
        </div>
      </main>

      {/* Mobile bottom navigation */}
      <nav
        aria-label="Quick"
        className="fixed inset-x-0 bottom-0 z-30 border-t bg-card/95 px-2 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur lg:hidden"
      >
        <ul className="grid grid-cols-5 items-end">
          {bottomNav.map((to, i) => {
            const item = navItems.find((n) => n.to === to)!
            const active = pathname === to || pathname.startsWith(to + '/')
            const Icon = item.icon
            const isAdd = to === '/add-match'
            return (
              <React.Fragment key={to}>
                <li className="flex justify-center">
                  {isAdd ? (
                    <Link
                      to={to}
                      aria-label="Add match"
                      className="-mt-6 inline-flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30 ring-4 ring-background transition-transform active:scale-95 motion-reduce:transition-none"
                    >
                      <Plus className="size-7" aria-hidden />
                    </Link>
                  ) : (
                    <Link
                      to={to}
                      className={cn(
                        'flex w-full flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-semibold',
                        active ? 'text-primary' : 'text-muted-foreground',
                      )}
                    >
                      <Icon className="size-5" aria-hidden />
                      {item.short}
                    </Link>
                  )}
                </li>
              </React.Fragment>
            )
          })}
          <li className="flex justify-center">
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              className="flex w-full flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-semibold text-muted-foreground"
            >
              <Menu className="size-5" aria-hidden />
              More
            </button>
          </li>
        </ul>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="right" className="court-lines w-[85vw] max-w-xs border-sidebar-border p-4 text-sidebar-foreground">
          <SheetHeader className="p-0">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <SheetDescription className="sr-only">All Badminton Cafe sections</SheetDescription>
            <Brand />
          </SheetHeader>
          <div className="mt-4 flex-1 overflow-y-auto">
            <NavList onNavigate={() => setMoreOpen(false)} />
          </div>
            <UserFooter />
        </SheetContent>
      </Sheet>
    </div>
  )
}
