import * as React from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { ArrowRight, Eye, EyeOff, Lock, Smartphone } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ShuttleMark } from '@/components/league/bits'
import { normalizeMobile, useLeague } from '@/lib/league/store'

export const Route = createFileRoute('/')({
  component: SignIn,
})

const hero = (w: number) => `/.netlify/images?url=/img/court-hero.png&w=${w}&fm=webp&q=78`

function SignIn() {
  const { signIn, loading, currentUser } = useLeague()
  const navigate = useNavigate()
  const [mobile, setMobile] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [showPassword, setShowPassword] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)
  const [pending, setPending] = React.useState(false)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const digits = normalizeMobile(mobile)
    if (digits.length !== 10) return setError('Enter your 10-digit mobile number.')
    if (!password) return setError('Enter your password.')
    setPending(true)
    setError(null)
    void signIn(digits, password)
      .then((player) => {
        toast.success(`Welcome back, ${player.name}!`)
        navigate({ to: '/dashboard' })
      })
      .catch((err: unknown) => setError(err instanceof Error ? err.message : 'Unable to sign in.'))
      .finally(() => setPending(false))
  }

  return (
    <div className="min-h-dvh bg-court-deep lg:grid lg:grid-cols-[1.1fr_1fr]">
      {/* Hero */}
      <div className="relative h-[46dvh] min-h-80 overflow-hidden lg:h-dvh">
        <img
          src={hero(900)}
          srcSet={`${hero(600)} 600w, ${hero(900)} 900w, ${hero(1400)} 1400w`}
          sizes="(min-width: 1024px) 55vw, 100vw"
          alt="A feather shuttlecock resting on a green badminton court under arena lights"
          className="absolute inset-0 size-full object-cover object-[50%_70%]"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-court-deep/70 via-court-deep/10 to-court-deep lg:bg-gradient-to-r lg:from-court-deep/60 lg:via-transparent lg:to-court-deep" />
        <div className="relative flex h-full flex-col justify-between p-6 text-sidebar-foreground sm:p-10">
          <div className="rise-in flex items-center gap-2.5">
            <span className="inline-flex size-10 items-center justify-center rounded-xl bg-accent text-court">
              <ShuttleMark className="size-7" />
            </span>
            <span className="font-display text-xl font-extrabold tracking-tight">Badminton Cafe</span>
          </div>
          <div className="rise-in hidden max-w-md lg:block" style={{ animationDelay: '120ms' }}>
            <p className="mb-3 text-xs font-semibold tracking-[0.24em] text-accent uppercase">Doubles League</p>
            <p className="font-display text-6xl leading-[0.95] font-extrabold tracking-tight">
              Play.
              <br />
              Compete.
              <br />
              <span className="text-accent">Connect.</span>
            </p>
            <p className="mt-5 max-w-sm text-base opacity-80">
              Every rally counted. Every partnership remembered. The private home of our morning doubles.
            </p>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="relative -mt-16 flex items-start justify-center px-4 pb-10 lg:mt-0 lg:items-center lg:px-10">
        <div
          className="rise-in w-full max-w-md rounded-3xl bg-card p-6 shadow-2xl shadow-black/30 sm:p-8"
          style={{ animationDelay: '80ms' }}
        >
          <p className="text-xs font-semibold tracking-[0.18em] text-primary uppercase lg:hidden">Play • Compete • Connect</p>
          <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">Sign in with your mobile number and password.</p>

          <form onSubmit={submit} className="mt-6 grid gap-4" noValidate>
            <div className="grid gap-1.5">
              <Label htmlFor="mobile">Mobile number</Label>
              <div className="flex h-12 items-center rounded-xl border border-input bg-card focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/40">
                <span className="flex h-full items-center gap-1.5 border-r px-3 text-sm font-semibold text-muted-foreground">
                  <Smartphone className="size-4" aria-hidden /> +91
                </span>
                <input
                  id="mobile"
                  type="tel"
                  inputMode="numeric"
                  autoComplete="tel-national"
                  placeholder="98765 43210"
                  maxLength={14}
                  value={mobile}
                  onChange={(e) => {
                    setMobile(e.target.value)
                    setError(null)
                  }}
                  aria-invalid={Boolean(error)}
                  className="tabular h-full min-w-0 flex-1 bg-transparent px-3 text-base tracking-wide outline-none"
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value)
                    setError(null)
                  }}
                  className="h-12 rounded-xl pr-11 pl-10 text-base"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute top-1/2 right-2 inline-flex size-8 -translate-y-1/2 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted"
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>

            {error && (
              <p role="alert" className="rounded-xl bg-destructive/8 px-3 py-2 text-sm font-medium text-destructive">
                {error}
              </p>
            )}

            <Button type="submit" size="lg" disabled={pending} className="mt-1 h-12 rounded-xl text-base font-bold">
              {pending ? 'Signing in…' : 'Sign in'}
              {!pending && <ArrowRight aria-hidden />}
            </Button>
          </form>

          {loading && <p className="mt-4 text-center text-xs text-muted-foreground">Checking your session…</p>}
          {currentUser && <p className="mt-4 text-center text-xs text-muted-foreground">You are already signed in as {currentUser.name}.</p>}
          <p className="mt-6 text-center text-xs text-muted-foreground">
            Private league · Accounts are created by the Super Admin
          </p>
        </div>
      </div>
    </div>
  )
}
