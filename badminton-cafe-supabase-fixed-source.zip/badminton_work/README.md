# Badminton Cafe — Supabase-connected source

This is the editable TanStack Start application source. It replaces the preview fixtures with live Supabase Auth and PostgREST data. It does not migrate, truncate, or recreate the existing Supabase tables.

## Required environment variables

Set these in Netlify Site configuration → Environment variables:

- `VITE_SUPABASE_URL`: the Badminton Cafe Supabase Project URL.
- `VITE_SUPABASE_ANON_KEY`: the project's publishable key (or legacy anon key). This is safe for browser use only when RLS is enabled.
- `SUPABASE_SERVICE_ROLE_KEY`: the Supabase secret/service-role key. Server-side Netlify Function only. Never add a `VITE_` prefix and never expose it in browser code.

`.env.example` shows the expected format. Do not commit real keys to GitHub.

## Authentication convention

Existing Auth users sign in with the internal email `${10DigitMobile}@players.badmintoncafe.app` and their existing password. The browser sends the password only to Supabase Auth over HTTPS. No password is stored in the application database.

## Data model used (existing tables)

- `public.players(id, name, mobile, is_active, created_at)`
- `public.profiles(user_id, player_id, role, created_at)`
- `public.matches(id, team_a_player_1, team_a_player_2, team_b_player_1, team_b_player_2, winner_team, played_at, created_by, created_at)`

The app uses the existing RLS policies. Match insert sets `created_by` to the authenticated Supabase Auth user ID. Match edit/delete rely on the database's admin RLS policies.

## Adding new players

The `netlify/functions/admin-create-player.ts` function creates the Auth account, player row, and profile row. It checks the caller's authenticated user and admin role before using the service-role key. Configure the three environment variables above for this function. The service-role key must remain server-side.

## Build and deploy

- Node 24 (see `.nvmrc` and `netlify.toml`).
- Build command: `npm run build`
- Publish directory: `dist/client`
- Netlify Functions directory: `netlify/functions`

Deploy this source through a Git-connected Netlify site or a local Netlify CLI build. Do not upload this source ZIP to Netlify Drop as if it were already-built static assets.

## Safety

The app no longer imports or contains the old generated fixture module. Empty Supabase match results remain empty. No match is seeded or generated on app load, login, or refresh. Do not run destructive SQL migrations to use this source.
