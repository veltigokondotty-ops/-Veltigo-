/** Creates an Auth user + player + profile. Service role is server-only. */
export default async (request: Request) => {
  const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
  if (request.method !== 'POST') return json(405, { error: 'Method not allowed' })
  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
  const anonKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!supabaseUrl || !anonKey || !serviceKey) return json(500, { error: 'Server Supabase settings are missing. Ask the site administrator to configure them.' })
  const bearer = request.headers.get('authorization') || ''
  const accessToken = bearer.replace(/^Bearer\s+/i, '')
  if (!accessToken) return json(401, { error: 'Please sign in.' })
  const headers = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, 'Content-Type': 'application/json' }
  try {
    const callerResponse = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: anonKey, Authorization: `Bearer ${accessToken}` } })
    if (!callerResponse.ok) return json(401, { error: 'Your session has expired. Please sign in again.' })
    const caller = await callerResponse.json() as { id: string }
    const profileResponse = await fetch(`${supabaseUrl}/rest/v1/profiles?select=role&user_id=eq.${encodeURIComponent(caller.id)}`, { headers })
    const profiles = await profileResponse.json() as Array<{ role: string }>
    if (!profileResponse.ok || !profiles.some((p) => p.role === 'admin' || p.role === 'super_admin')) return json(403, { error: 'Only the Super Admin can add players.' })

    const payload = await request.json() as { name?: string; mobile?: string; password?: string }
    const name = (payload.name || '').trim()
    const mobile = (payload.mobile || '').replace(/\D/g, '').slice(-10)
    const password = payload.password || ''
    if (name.length < 2 || !/^[6-9]\d{9}$/.test(mobile) || password.length < 8) return json(400, { error: 'Enter a valid name, 10-digit mobile number and password of at least 8 characters.' })
    const duplicate = await fetch(`${supabaseUrl}/rest/v1/players?select=id&mobile=eq.${mobile}`, { headers })
    const duplicateRows = await duplicate.json() as unknown[]
    if (duplicateRows.length) return json(409, { error: 'This mobile number is already registered.' })

    const authResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users`, { method: 'POST', headers, body: JSON.stringify({ email: `${mobile}@players.badmintoncafe.app`, password, email_confirm: true }) })
    const authUser = await authResponse.json() as { id?: string; msg?: string; message?: string }
    if (!authResponse.ok || !authUser.id) return json(authResponse.status, { error: authUser.message || authUser.msg || 'Unable to create login account.' })

    const playerResponse = await fetch(`${supabaseUrl}/rest/v1/players?select=id`, { method: 'POST', headers: { ...headers, Prefer: 'return=representation' }, body: JSON.stringify({ name, mobile, is_active: true }) })
    const playerRows = await playerResponse.json() as Array<{ id: string }>
    if (!playerResponse.ok || !playerRows[0]?.id) {
      await fetch(`${supabaseUrl}/auth/v1/admin/users/${authUser.id}`, { method: 'DELETE', headers })
      return json(500, { error: 'Login created, but player record failed. Please retry or contact support.' })
    }
    const profileResponse2 = await fetch(`${supabaseUrl}/rest/v1/profiles`, { method: 'POST', headers, body: JSON.stringify({ user_id: authUser.id, player_id: playerRows[0].id, role: 'member' }) })
    if (!profileResponse2.ok) {
      await fetch(`${supabaseUrl}/rest/v1/players?id=eq.${playerRows[0].id}`, { method: 'DELETE', headers })
      await fetch(`${supabaseUrl}/auth/v1/admin/users/${authUser.id}`, { method: 'DELETE', headers })
      return json(500, { error: 'Player profile could not be linked. No new player was kept.' })
    }
    return json(201, { playerId: playerRows[0].id })
  } catch (error) {
    return json(500, { error: error instanceof Error ? error.message : 'Unexpected server error.' })
  }
}
