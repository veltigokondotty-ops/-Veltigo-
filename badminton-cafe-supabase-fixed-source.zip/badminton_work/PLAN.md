# Badminton Cafe — Product Roadmap

Badminton Cafe is a private, mobile-first doubles league app (2 vs 2, winner only, no scores) for a group that starts with 7 players and can grow without limit. It covers individual and partnership statistics, daily performance in Asia/Kolkata time, and admin tools reserved for the Super Admin, Niyas.

The data and security source of truth is the group's **existing Supabase project, "Badminton Cafe"**: the `players`, `profiles` and `matches` tables, the `player_leaderboard`, `team_combination_stats` and `daily_player_stats` views, and the Row Level Security policies already in place. The app uses those as they are. It never creates a second database and never overwrites existing data.

---

## Milestone 1 — Product surface ✅ (done)

Every screen is built, branded and clickable, running on realistic preview data from `src/lib/league/fixtures.ts`.

- Sign-in screen (mobile number + password, no OTP)
- Dashboard, Add Match, Match History, All-Time Leaderboard, Daily Performance, Partnerships, Player Profiles, Player Management (Super Admin only)
- Stats engine (`src/lib/league/stats.ts`): wins and losses, win %, ranking with shared ranks for equal percentages, 5-match qualification, partnerships regardless of pick order, daily stats and joint Player of the Day
- Player-selection rules (`src/lib/league/selection.ts`): each pick is removed from the following lists, earlier changes clear conflicting later picks, and only active players can be picked
- A "Preview as" switcher so member and Super Admin views can both be reviewed

## Milestone 2 — Connect and inspect Supabase (do this first, before any database change)

1. Authorize the Supabase connection and read the live schema: columns, keys, constraints, views, RLS policies, triggers and functions.
2. Write up any integration issues for the product owner **before** changing anything. Questions to answer:
   - How `profiles` links to `auth.users` and `players` (role column, active flag)
   - The internal email format, used for the mobile-number-to-email mapping
   - How `matches` stores teams and the winner (columns, enum or text, check constraints against duplicate players)
   - Whether the views apply the same rules as the app: the 5-match minimum, shared ranks, unordered pairs, and Asia/Kolkata day boundaries in `daily_player_stats`
   - Whether the RLS policies already limit match update/delete and player writes to the Super Admin
3. Configure `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` as Netlify environment variables, requested securely from the owner. Only the publishable key ever reaches the browser.
4. Add `@supabase/supabase-js` and a typed client module. Generate database types from the live schema.

## Milestone 3 — Authentication

- Sign in with mobile number + password: normalize the number, map it to the internal email, then call `signInWithPassword`.
- Load the session and role from `profiles`. Add route guards for the app and for `/admin/*`.
- Sign out, handle session expiry, and show friendly errors (wrong password, inactive player).
- Remove the "Preview as" switcher and the preview sign-in path.

## Milestone 4 — Live data (read)

- Replace `fixtures.ts` and the in-session store with Supabase queries. Keep the `useLeague()` interface so screens don't change.
- Use the existing views where they match the requirements. Otherwise run the shared stats engine over the `matches` rows, and document which source each screen uses.
- Add loading skeletons, error states, and refresh after changes (optionally Supabase Realtime).

## Milestone 5 — Match writes

- Add Match inserts into `matches` after client validation. The database constraints and RLS are the final check.
- Super Admin edit and permanent delete (confirmed in the UI; no soft delete). RLS must reject both for members.
- All statistics refresh after every change.

## Milestone 6 — Player management (Super Admin)

- A server-side endpoint (TanStack Start server function) that creates a Supabase Auth user with the internal email + initial password, then the `players`/`profiles` rows. It uses a server-only secret key stored as a Netlify environment variable and never exposed to the browser.
- The endpoint checks the caller's session and Super Admin role before doing anything.
- Edit name/mobile with duplicate-mobile prevention (database unique constraint + UI message).
- Activate or deactivate. Historical matches are never deleted.

## Milestone 7 — Security and end-to-end verification

Test with real member and admin accounts:

- Member and admin login; member blocked from editing, deleting and player management **at the RLS level** (direct API calls, not just hidden buttons)
- Adding matches; duplicate-selection prevention; inactive players not selectable
- Individual stats, partnership stats, leaderboard qualification and shared ranks
- Daily stats across IST midnight, historical dates, joint Player of the Day
- Admin edit and permanent delete refreshing all stats
- Adding and deactivating players

## Milestone 8 — Polish

- Installable PWA (home-screen icon, offline shell)
- Head-to-head comparisons and monthly summaries
- Shareable daily recap card
